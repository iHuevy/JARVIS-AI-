"""
JARVIS Cleaner Module — Free up disk space by removing temp files and cache.
"""

import os
import shutil
import logging
import platform
from pathlib import Path
from typing import Optional

logger = logging.getLogger("JARVIS.Cleaner")


class PCCleaner:
    """Safely cleans temporary files, cache, and recycle bin."""

    def __init__(self):
        self.os_type = platform.system().lower()

    def scan(self) -> dict:
        """Scan for cleanable files without deleting anything."""
        targets = self._get_clean_targets()
        total_size = 0
        items = []

        for label, paths in targets.items():
            category_size = 0
            category_count = 0
            for p in paths:
                path = Path(p).expanduser()
                if path.exists():
                    size = self._get_size(path)
                    category_size += size
                    category_count += sum(1 for _ in path.rglob("*") if _.is_file()) if path.is_dir() else 1
            if category_size > 0:
                items.append({
                    "category": label,
                    "size_mb": round(category_size / (1024**2), 2),
                    "files": category_count,
                })
                total_size += category_size

        return {
            "success": True,
            "total_mb": round(total_size / (1024**2), 2),
            "total_gb": round(total_size / (1024**3), 3),
            "categories": items,
        }

    def clean(self, categories: Optional[list[str]] = None) -> dict:
        """
        Clean temporary files. If categories is None, clean all.
        Returns summary of what was removed.
        """
        targets = self._get_clean_targets()
        if categories:
            targets = {k: v for k, v in targets.items() if k in categories}

        freed_bytes = 0
        cleaned = []
        errors = []

        for label, paths in targets.items():
            category_freed = 0
            for p in paths:
                path = Path(p).expanduser()
                if not path.exists():
                    continue
                try:
                    size_before = self._get_size(path)
                    if path.is_dir():
                        for item in path.iterdir():
                            try:
                                item_size = self._get_size(item)
                                if item.is_dir():
                                    shutil.rmtree(str(item), ignore_errors=True)
                                else:
                                    item.unlink(missing_ok=True)
                                category_freed += item_size
                            except PermissionError:
                                pass
                    else:
                        path.unlink(missing_ok=True)
                        category_freed += size_before
                except PermissionError as e:
                    errors.append(f"{p}: Permission denied")
                except Exception as e:
                    errors.append(f"{p}: {str(e)}")

            if category_freed > 0:
                cleaned.append({
                    "category": label,
                    "freed_mb": round(category_freed / (1024**2), 2),
                })
                freed_bytes += category_freed

        # Empty recycle bin / trash
        try:
            self._empty_trash()
            cleaned.append({"category": "Recycle Bin / Trash", "freed_mb": "varies"})
        except Exception as e:
            errors.append(f"Trash: {str(e)}")

        return {
            "success": True,
            "freed_mb": round(freed_bytes / (1024**2), 2),
            "freed_gb": round(freed_bytes / (1024**3), 3),
            "categories_cleaned": cleaned,
            "errors": errors if errors else None,
        }

    def clean_browser_cache(self, browser: str = "all") -> dict:
        """Clean specific browser caches."""
        browser_paths = {}

        if self.os_type == "windows":
            appdata = os.getenv("APPDATA", "")
            localappdata = os.getenv("LOCALAPPDATA", "")
            browser_paths = {
                "chrome": [f"{localappdata}\\Google\\Chrome\\User Data\\Default\\Cache"],
                "firefox": [f"{appdata}\\Mozilla\\Firefox\\Profiles"],
                "edge": [f"{localappdata}\\Microsoft\\Edge\\User Data\\Default\\Cache"],
            }
        elif self.os_type == "darwin":
            home = str(Path.home())
            browser_paths = {
                "chrome": [f"{home}/Library/Caches/Google/Chrome"],
                "firefox": [f"{home}/Library/Caches/Firefox"],
                "safari": [f"{home}/Library/Caches/com.apple.Safari"],
            }
        else:
            home = str(Path.home())
            browser_paths = {
                "chrome": [f"{home}/.cache/google-chrome"],
                "firefox": [f"{home}/.cache/mozilla/firefox"],
            }

        freed = 0
        cleaned = []

        targets = browser_paths if browser == "all" else {browser: browser_paths.get(browser, [])}
        for name, paths in targets.items():
            for p in paths:
                path = Path(p)
                if path.exists():
                    size = self._get_size(path)
                    try:
                        shutil.rmtree(str(path), ignore_errors=True)
                        freed += size
                        cleaned.append(name)
                    except:
                        pass

        return {
            "success": True,
            "freed_mb": round(freed / (1024**2), 2),
            "browsers_cleaned": cleaned,
        }

    def get_disk_info(self) -> dict:
        """Get disk usage information."""
        import psutil
        partitions = []
        for part in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(part.mountpoint)
                partitions.append({
                    "device": part.device,
                    "mountpoint": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024**3), 2),
                    "used_gb": round(usage.used / (1024**3), 2),
                    "free_gb": round(usage.free / (1024**3), 2),
                    "percent_used": usage.percent,
                })
            except PermissionError:
                pass
        return {"success": True, "partitions": partitions}

    def _get_clean_targets(self) -> dict[str, list[str]]:
        """Return OS-specific paths to clean."""
        if self.os_type == "windows":
            temp = os.getenv("TEMP", "C:\\Windows\\Temp")
            return {
                "Windows Temp": [temp, "C:\\Windows\\Temp"],
                "User Temp": [os.path.expanduser("~\\AppData\\Local\\Temp")],
                "Prefetch": ["C:\\Windows\\Prefetch"],
                "Recent Files": [os.path.expanduser("~\\AppData\\Roaming\\Microsoft\\Windows\\Recent")],
                "Thumbnail Cache": [os.path.expanduser("~\\AppData\\Local\\Microsoft\\Windows\\Explorer")],
            }
        elif self.os_type == "darwin":
            return {
                "System Caches": ["/private/var/folders"],
                "User Caches": [os.path.expanduser("~/Library/Caches")],
                "User Logs": [os.path.expanduser("~/Library/Logs")],
                "Crash Reports": [os.path.expanduser("~/Library/Application Support/CrashReporter")],
            }
        else:  # Linux
            return {
                "User Cache": [os.path.expanduser("~/.cache")],
                "Tmp Files": ["/tmp"],
                "Thumbnails": [os.path.expanduser("~/.cache/thumbnails")],
                "Package Cache": ["/var/cache/apt/archives"],
            }

    def _get_size(self, path: Path) -> int:
        """Get size of file or folder in bytes."""
        if path.is_file():
            return path.stat().st_size
        total = 0
        try:
            for p in path.rglob("*"):
                if p.is_file():
                    try:
                        total += p.stat().st_size
                    except:
                        pass
        except:
            pass
        return total

    def _empty_trash(self):
        """Empty the system trash/recycle bin."""
        try:
            import send2trash
            if self.os_type == "windows":
                import winreg
                os.system("PowerShell.exe -Command Clear-RecycleBin -Confirm:$false")
            elif self.os_type == "darwin":
                os.system("rm -rf ~/.Trash/*")
            else:
                trash = Path.home() / ".local/share/Trash/files"
                if trash.exists():
                    shutil.rmtree(str(trash), ignore_errors=True)
                    trash.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.warning(f"Could not empty trash: {e}")
