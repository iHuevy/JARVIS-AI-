"""
JARVIS GUI — Neon-style dashboard with chat interface and system stats.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
import math
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

logger = logging.getLogger("JARVIS.GUI")

# ── Color Palette ─────────────────────────────────────────────────────────────
COLORS = {
    "bg_dark":      "#020B18",
    "bg_panel":     "#050F20",
    "bg_input":     "#071525",
    "neon_cyan":    "#00D4FF",
    "neon_blue":    "#0080FF",
    "neon_bright":  "#40E8FF",
    "accent_glow":  "#004466",
    "text_primary": "#E0F8FF",
    "text_dim":     "#4A7A8A",
    "text_muted":   "#1E3A4A",
    "border":       "#0A2A3A",
    "user_msg":     "#003344",
    "jarvis_msg":   "#001A2A",
    "warn":         "#FF6B00",
    "success":      "#00FF88",
    "error":        "#FF3344",
}


class JARVISWindow:
    """Main JARVIS GUI window."""

    def __init__(
        self,
        on_input: Callable[[str], None],
        on_screenshot: Callable[[], None],
        on_voice_toggle: Callable[[], None],
    ):
        self.on_input = on_input
        self.on_screenshot = on_screenshot
        self.on_voice_toggle = on_voice_toggle
        self.is_listening = False
        self._build_window()

    def _build_window(self):
        """Construct the main window."""
        self.root = tk.Tk()
        self.root.title("JARVIS — AI Assistant")
        self.root.configure(bg=COLORS["bg_dark"])
        self.root.geometry("900x700")
        self.root.minsize(700, 500)

        # Remove default title bar on Windows (optional)
        # self.root.overrideredirect(True)

        # ── Load / generate icon ──────────────────────────────────────────────
        self._set_icon()

        # ── Main layout ───────────────────────────────────────────────────────
        self._build_header()
        self._build_main_area()
        self._build_input_area()
        self._build_status_bar()

        # Start clock and stats update
        self._start_updates()

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _set_icon(self):
        try:
            from assets.icon_gen import create_jarvis_icon
            icon_path = create_jarvis_icon(64)
            if icon_path and Path(icon_path).exists():
                from PIL import ImageTk, Image
                img = Image.open(icon_path).resize((32, 32))
                self._icon_img = ImageTk.PhotoImage(img)
                self.root.iconphoto(True, self._icon_img)
        except:
            pass

    def _build_header(self):
        """Top header bar."""
        header = tk.Frame(self.root, bg=COLORS["bg_dark"], height=70)
        header.pack(fill=tk.X, padx=0, pady=0)
        header.pack_propagate(False)

        # Canvas for animated logo
        self.logo_canvas = tk.Canvas(
            header, width=60, height=60,
            bg=COLORS["bg_dark"], highlightthickness=0
        )
        self.logo_canvas.pack(side=tk.LEFT, padx=(16, 0), pady=5)
        self._draw_logo()

        # Title block
        title_frame = tk.Frame(header, bg=COLORS["bg_dark"])
        title_frame.pack(side=tk.LEFT, padx=12, pady=8)

        tk.Label(
            title_frame,
            text="JARVIS",
            font=("Courier New", 26, "bold"),
            fg=COLORS["neon_cyan"],
            bg=COLORS["bg_dark"]
        ).pack(anchor=tk.W)

        tk.Label(
            title_frame,
            text="Just A Rather Very Intelligent System",
            font=("Courier New", 8),
            fg=COLORS["text_dim"],
            bg=COLORS["bg_dark"]
        ).pack(anchor=tk.W)

        # Made by iHuevy badge
        badge_frame = tk.Frame(header, bg="#001A2A", relief=tk.FLAT, bd=0)
        badge_frame.pack(side=tk.LEFT, padx=16, pady=20)

        badge_inner = tk.Frame(badge_frame, bg="#001A2A")
        badge_inner.pack(padx=8, pady=3)

        tk.Label(
            badge_inner,
            text="⚡  Made by ",
            font=("Courier New", 8),
            fg=COLORS["text_dim"],
            bg="#001A2A"
        ).pack(side=tk.LEFT)

        tk.Label(
            badge_inner,
            text="iHuevy",
            font=("Courier New", 9, "bold"),
            fg=COLORS["neon_cyan"],
            bg="#001A2A"
        ).pack(side=tk.LEFT)

        # Separator line under badge
        sep = tk.Frame(badge_frame, bg=COLORS["neon_cyan"], height=1)
        sep.pack(fill=tk.X, padx=4)

        # Right side — clock + controls
        right_frame = tk.Frame(header, bg=COLORS["bg_dark"])
        right_frame.pack(side=tk.RIGHT, padx=16)

        self.clock_label = tk.Label(
            right_frame,
            text="",
            font=("Courier New", 14, "bold"),
            fg=COLORS["neon_cyan"],
            bg=COLORS["bg_dark"]
        )
        self.clock_label.pack()

        self.date_label = tk.Label(
            right_frame,
            text="",
            font=("Courier New", 8),
            fg=COLORS["text_dim"],
            bg=COLORS["bg_dark"]
        )
        self.date_label.pack()

        # Separator
        sep = tk.Frame(self.root, bg=COLORS["neon_cyan"], height=1)
        sep.pack(fill=tk.X, padx=0)
        sep2 = tk.Frame(self.root, bg=COLORS["bg_dark"], height=1)
        sep2.pack(fill=tk.X)

    def _draw_logo(self):
        """Draw animated neon J logo on canvas."""
        c = self.logo_canvas
        c.delete("all")
        cx, cy, r = 30, 30, 26

        # Outer ring
        c.create_oval(cx - r, cy - r, cx + r, cy + r, outline=COLORS["neon_cyan"], width=2)

        # Hexagon
        points = []
        for i in range(6):
            angle = math.radians(60 * i - 30)
            points.extend([cx + 18 * math.cos(angle), cy + 18 * math.sin(angle)])
        c.create_polygon(points, outline=COLORS["neon_cyan"], fill=COLORS["bg_panel"], width=1)

        # J letter
        c.create_line(cx, cy - 12, cx + 7, cy - 12, fill=COLORS["neon_cyan"], width=3)
        c.create_line(cx + 7, cy - 12, cx + 7, cy + 6, fill=COLORS["neon_cyan"], width=3)
        c.create_arc(cx - 3, cy, cx + 10, cy + 14, start=0, extent=200,
                     outline=COLORS["neon_cyan"], width=3, style=tk.ARC)

    def _build_main_area(self):
        """Main chat area + sidebar."""
        main_frame = tk.Frame(self.root, bg=COLORS["bg_dark"])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)

        # ── Chat area ─────────────────────────────────────────────────────────
        chat_frame = tk.Frame(main_frame, bg=COLORS["bg_dark"])
        chat_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8, 4), pady=8)

        # Chat header
        chat_header = tk.Frame(chat_frame, bg=COLORS["bg_dark"])
        chat_header.pack(fill=tk.X)
        tk.Label(
            chat_header,
            text="◈  NEURAL INTERFACE",
            font=("Courier New", 9, "bold"),
            fg=COLORS["text_dim"],
            bg=COLORS["bg_dark"]
        ).pack(side=tk.LEFT)

        # Chat box
        self.chat_box = scrolledtext.ScrolledText(
            chat_frame,
            bg=COLORS["bg_panel"],
            fg=COLORS["text_primary"],
            font=("Courier New", 10),
            insertbackground=COLORS["neon_cyan"],
            selectbackground=COLORS["accent_glow"],
            relief=tk.FLAT,
            borderwidth=0,
            wrap=tk.WORD,
            state=tk.DISABLED,
            padx=12,
            pady=8,
        )
        self.chat_box.pack(fill=tk.BOTH, expand=True, pady=(4, 0))

        # Configure text tags
        self.chat_box.tag_configure("user", foreground=COLORS["neon_bright"],
                                    font=("Courier New", 10, "bold"), spacing1=8)
        self.chat_box.tag_configure("jarvis", foreground=COLORS["text_primary"],
                                    font=("Courier New", 10), spacing1=4)
        self.chat_box.tag_configure("system", foreground=COLORS["text_dim"],
                                    font=("Courier New", 9, "italic"), spacing1=2)
        self.chat_box.tag_configure("label_user", foreground=COLORS["neon_cyan"],
                                    font=("Courier New", 9, "bold"))
        self.chat_box.tag_configure("label_jarvis", foreground=COLORS["neon_blue"],
                                    font=("Courier New", 9, "bold"))
        self.chat_box.tag_configure("success", foreground=COLORS["success"], font=("Courier New", 9))
        self.chat_box.tag_configure("error", foreground=COLORS["error"], font=("Courier New", 9))

        # ── Sidebar ───────────────────────────────────────────────────────────
        sidebar = tk.Frame(main_frame, bg=COLORS["bg_panel"], width=200)
        sidebar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 8), pady=8)
        sidebar.pack_propagate(False)

        self._build_sidebar(sidebar)

    def _build_sidebar(self, parent):
        """Build the right sidebar with stats and quick actions."""
        # System Stats section
        tk.Label(
            parent,
            text="◈  SYSTEMS",
            font=("Courier New", 9, "bold"),
            fg=COLORS["text_dim"],
            bg=COLORS["bg_panel"]
        ).pack(padx=8, pady=(12, 4), anchor=tk.W)

        sep = tk.Frame(parent, bg=COLORS["border"], height=1)
        sep.pack(fill=tk.X, padx=8)

        # Stats grid
        stats_frame = tk.Frame(parent, bg=COLORS["bg_panel"])
        stats_frame.pack(fill=tk.X, padx=8, pady=8)

        self.stat_labels = {}
        stats = [
            ("CPU", "cpu_val"),
            ("RAM", "ram_val"),
            ("DISK", "disk_val"),
            ("BATTERY", "batt_val"),
        ]
        for label, key in stats:
            row = tk.Frame(stats_frame, bg=COLORS["bg_panel"])
            row.pack(fill=tk.X, pady=2)
            tk.Label(row, text=label, font=("Courier New", 8), fg=COLORS["text_dim"],
                     bg=COLORS["bg_panel"], width=8, anchor=tk.W).pack(side=tk.LEFT)
            lbl = tk.Label(row, text="...", font=("Courier New", 8, "bold"),
                           fg=COLORS["neon_cyan"], bg=COLORS["bg_panel"], anchor=tk.E)
            lbl.pack(side=tk.RIGHT)
            self.stat_labels[key] = lbl

        # Progress bars
        sep2 = tk.Frame(parent, bg=COLORS["border"], height=1)
        sep2.pack(fill=tk.X, padx=8, pady=4)

        self.cpu_bar_var = tk.DoubleVar(value=0)
        self.ram_bar_var = tk.DoubleVar(value=0)

        for label, var in [("CPU Load", self.cpu_bar_var), ("RAM Used", self.ram_bar_var)]:
            tk.Label(parent, text=label, font=("Courier New", 7), fg=COLORS["text_dim"],
                     bg=COLORS["bg_panel"]).pack(padx=8, anchor=tk.W)
            bar_canvas = tk.Canvas(parent, height=6, bg=COLORS["bg_dark"],
                                   highlightthickness=0)
            bar_canvas.pack(fill=tk.X, padx=8, pady=(0, 6))
            bar_canvas.bind("<Configure>", lambda e, v=var, c=bar_canvas: self._draw_bar(c, v.get()))
            self.__dict__[f"_bar_canvas_{label[:3]}"] = (bar_canvas, var)

        # Quick Actions section
        sep3 = tk.Frame(parent, bg=COLORS["border"], height=1)
        sep3.pack(fill=tk.X, padx=8, pady=4)
        tk.Label(parent, text="◈  QUICK ACTIONS", font=("Courier New", 9, "bold"),
                 fg=COLORS["text_dim"], bg=COLORS["bg_panel"]).pack(padx=8, pady=(4, 8), anchor=tk.W)

        quick_actions = [
            ("📸 Screenshot", lambda: self.on_screenshot()),
            ("🧹 Clean PC",   lambda: self.on_input("scan and clean my PC")),
            ("💻 System Info", lambda: self.on_input("show me system info")),
            ("📁 Files",       lambda: self.on_input("list my home folder")),
        ]
        for label, cmd in quick_actions:
            btn = tk.Button(
                parent,
                text=label,
                command=cmd,
                font=("Courier New", 8),
                fg=COLORS["neon_cyan"],
                bg=COLORS["bg_dark"],
                activeforeground=COLORS["neon_bright"],
                activebackground=COLORS["accent_glow"],
                relief=tk.FLAT,
                cursor="hand2",
                bd=0,
                pady=4,
            )
            btn.pack(fill=tk.X, padx=8, pady=2)

        # Made by iHuevy footer
        footer_frame = tk.Frame(parent, bg=COLORS["bg_panel"])
        footer_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=8)
        sep_footer = tk.Frame(footer_frame, bg=COLORS["neon_cyan"], height=1)
        sep_footer.pack(fill=tk.X, padx=8, pady=(0, 4))
        tk.Label(
            footer_frame,
            text="Made by iHuevy",
            font=("Courier New", 8, "bold"),
            fg=COLORS["neon_cyan"],
            bg=COLORS["bg_panel"]
        ).pack()
        tk.Label(
            footer_frame,
            text="v2.0 — Claude Powered",
            font=("Courier New", 7),
            fg=COLORS["text_dim"],
            bg=COLORS["bg_panel"]
        ).pack()

    def _draw_bar(self, canvas, value):
        """Draw a neon progress bar."""
        canvas.delete("all")
        w = canvas.winfo_width()
        h = canvas.winfo_height()
        if w < 2:
            return
        fill_w = int(w * value / 100)
        canvas.create_rectangle(0, 0, w, h, fill=COLORS["bg_dark"], outline="")
        if fill_w > 0:
            color = COLORS["success"] if value < 70 else (COLORS["warn"] if value < 90 else COLORS["error"])
            canvas.create_rectangle(0, 0, fill_w, h, fill=color, outline="")

    def _build_input_area(self):
        """Bottom input area."""
        sep = tk.Frame(self.root, bg=COLORS["neon_cyan"], height=1)
        sep.pack(fill=tk.X)

        input_frame = tk.Frame(self.root, bg=COLORS["bg_input"], pady=8)
        input_frame.pack(fill=tk.X, padx=8, pady=(0, 0))

        # Mic button
        self.mic_btn = tk.Button(
            input_frame,
            text="🎤",
            font=("Arial", 14),
            fg=COLORS["neon_cyan"],
            bg=COLORS["bg_dark"],
            activeforeground=COLORS["neon_bright"],
            activebackground=COLORS["accent_glow"],
            relief=tk.FLAT,
            cursor="hand2",
            width=3,
            command=self._toggle_voice,
        )
        self.mic_btn.pack(side=tk.LEFT, padx=(4, 0))

        # Input field
        input_container = tk.Frame(input_frame, bg=COLORS["bg_dark"])
        input_container.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=8)

        self.input_var = tk.StringVar()
        self.input_field = tk.Entry(
            input_container,
            textvariable=self.input_var,
            font=("Courier New", 11),
            fg=COLORS["text_primary"],
            bg=COLORS["bg_dark"],
            insertbackground=COLORS["neon_cyan"],
            selectbackground=COLORS["accent_glow"],
            relief=tk.FLAT,
            bd=0,
        )
        self.input_field.pack(fill=tk.BOTH, expand=True, ipady=8, padx=8)
        self.input_field.bind("<Return>", self._on_enter)
        self.input_field.bind("<FocusIn>", lambda e: self._set_placeholder(False))
        self.input_field.bind("<FocusOut>", lambda e: self._set_placeholder(True))

        # Underline
        underline = tk.Frame(input_container, bg=COLORS["neon_cyan"], height=1)
        underline.pack(fill=tk.X, padx=4)

        self._set_placeholder(True)

        # Send button
        send_btn = tk.Button(
            input_frame,
            text="  SEND  ",
            font=("Courier New", 9, "bold"),
            fg=COLORS["bg_dark"],
            bg=COLORS["neon_cyan"],
            activeforeground=COLORS["bg_dark"],
            activebackground=COLORS["neon_bright"],
            relief=tk.FLAT,
            cursor="hand2",
            command=self._on_send,
        )
        send_btn.pack(side=tk.RIGHT, padx=4, ipadx=4, ipady=6)

    def _build_status_bar(self):
        """Bottom status bar."""
        status_frame = tk.Frame(self.root, bg=COLORS["bg_dark"], height=24)
        status_frame.pack(fill=tk.X, side=tk.BOTTOM)
        status_frame.pack_propagate(False)

        sep = tk.Frame(status_frame, bg=COLORS["border"], height=1)
        sep.pack(fill=tk.X)

        self.status_label = tk.Label(
            status_frame,
            text="● ONLINE  |  JARVIS READY",
            font=("Courier New", 8),
            fg=COLORS["success"],
            bg=COLORS["bg_dark"],
            anchor=tk.W
        )
        self.status_label.pack(side=tk.LEFT, padx=12)

        tk.Label(
            status_frame,
            text="Made by iHuevy  |  Powered by Claude AI",
            font=("Courier New", 8),
            fg=COLORS["text_dim"],
            bg=COLORS["bg_dark"],
            anchor=tk.E
        ).pack(side=tk.RIGHT, padx=12)

    def _set_placeholder(self, show: bool):
        current = self.input_var.get()
        placeholder = "Talk to JARVIS..."
        if show and not current:
            self.input_field.configure(fg=COLORS["text_muted"])
            self.input_var.set(placeholder)
        elif not show and current == placeholder:
            self.input_var.set("")
            self.input_field.configure(fg=COLORS["text_primary"])

    def _on_enter(self, event=None):
        self._on_send()

    def _on_send(self):
        text = self.input_var.get().strip()
        placeholder = "Talk to JARVIS..."
        if text and text != placeholder:
            self.input_var.set("")
            self.add_user_message(text)
            threading.Thread(target=self.on_input, args=(text,), daemon=True).start()

    def _toggle_voice(self):
        self.is_listening = not self.is_listening
        if self.is_listening:
            self.mic_btn.configure(fg=COLORS["success"], bg=COLORS["accent_glow"])
            self.set_status("● LISTENING...", COLORS["success"])
        else:
            self.mic_btn.configure(fg=COLORS["neon_cyan"], bg=COLORS["bg_dark"])
            self.set_status("● ONLINE  |  JARVIS READY", COLORS["success"])
        threading.Thread(target=self.on_voice_toggle, daemon=True).start()

    # ── Public methods ─────────────────────────────────────────────────────────
    def add_user_message(self, text: str):
        """Add a user message to the chat."""
        self._append_message(f"▶  YOU", "label_user")
        self._append_message(f"  {text}\n", "user")

    def add_jarvis_message(self, text: str):
        """Add a JARVIS response to the chat."""
        self._append_message("◈  JARVIS", "label_jarvis")
        self._append_message(f"  {text}\n", "jarvis")

    def add_system_message(self, text: str, level: str = "info"):
        """Add a system/status message."""
        tag = "system" if level == "info" else level
        prefix = {"info": "ℹ", "success": "✓", "error": "✗", "warn": "⚠"}.get(level, "·")
        self._append_message(f"  {prefix} {text}\n", tag)

    def _append_message(self, text: str, tag: str):
        """Append text to the chat box."""
        self.chat_box.configure(state=tk.NORMAL)
        self.chat_box.insert(tk.END, text, tag)
        self.chat_box.configure(state=tk.DISABLED)
        self.chat_box.see(tk.END)

    def set_status(self, text: str, color: str = None):
        """Update the status bar."""
        self.status_label.configure(text=text, fg=color or COLORS["success"])

    def set_thinking(self, thinking: bool):
        """Show/hide thinking indicator."""
        if thinking:
            self.set_status("◈ PROCESSING...", COLORS["neon_cyan"])
        else:
            self.set_status("● ONLINE  |  JARVIS READY", COLORS["success"])

    def update_stats(self, cpu: float, ram: float, disk: float, battery: Optional[float] = None):
        """Update system stats in the sidebar."""
        self.stat_labels["cpu_val"].configure(text=f"{cpu:.0f}%")
        self.stat_labels["ram_val"].configure(text=f"{ram:.0f}%")
        self.stat_labels["disk_val"].configure(text=f"{disk:.0f}%")
        self.stat_labels["batt_val"].configure(
            text=f"{battery:.0f}%" if battery is not None else "N/A"
        )

        # Update progress bars
        self.cpu_bar_var.set(cpu)
        self.ram_bar_var.set(ram)

        for label, (canvas, var) in {
            "CPU": (self._bar_canvas_CPU if hasattr(self, "_bar_canvas_CPU") else None, self.cpu_bar_var),
        }.items():
            pass

    def _start_updates(self):
        """Start background update loops."""
        def update_clock():
            while True:
                now = datetime.now()
                self.clock_label.configure(text=now.strftime("%H:%M:%S"))
                self.date_label.configure(text=now.strftime("%A, %B %d"))
                time.sleep(1)

        def update_stats():
            while True:
                try:
                    import psutil
                    cpu = psutil.cpu_percent(interval=None)
                    mem = psutil.virtual_memory()
                    disk = psutil.disk_usage("/")
                    batt = None
                    try:
                        b = psutil.sensors_battery()
                        if b:
                            batt = b.percent
                    except:
                        pass
                    self.update_stats(cpu, mem.percent, disk.percent, batt)
                except:
                    pass
                time.sleep(3)

        threading.Thread(target=update_clock, daemon=True).start()
        threading.Thread(target=update_stats, daemon=True).start()

    def _on_close(self):
        """Handle window close."""
        self.root.destroy()

    def run(self):
        """Start the Tkinter main loop."""
        # Show welcome message
        self.add_system_message("JARVIS ONLINE — AI systems nominal.", "success")
        self.add_jarvis_message(
            "Good day. All systems are online and operational. "
            "I'm JARVIS — your intelligent desktop assistant. "
            "How may I assist you today?"
        )
        self.root.mainloop()
