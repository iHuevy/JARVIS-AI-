"""
JARVIS File Module — Read, search, organize files on the PC.
"""

import os
import shutil
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional

logger = logging.getLogger("JARVIS.Files")

# File type categories for organizing
FILE_CATEGORIES = {
    "Images":     [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico", ".tiff"],
    "Videos":     [".mp4", ".avi", ".mov", ".mkv", ".wmv", ".flv", ".webm", ".m4v"],
    "Audio":      [".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a"],
    "Documents":  [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".odt"],
    "Code":       [".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp", ".go", ".rs", ".rb", ".php"],
    "Archives":   [".zip", ".tar", ".gz", ".rar", ".7z", ".bz2"],
    "Data":       [".json", ".csv", ".xml", ".yaml", ".yml", ".sql", ".db"],
    "Executables":[".exe", ".msi", ".deb", ".dmg", ".sh", ".bat", ".cmd"],
}


class FileManager:
    """Handles all file operations for JARVIS."""

    def read_file(self, path: str) -> dict:
        """Read a file and return its content."""
        path = Path(path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {path}"}

        try:
            size = path.stat().st_size
            if size > 10 * 1024 * 1024:  # 10MB limit
                return {"success": False, "error": "File too large (>10MB). Use search/read specific lines."}

            # Try to read as text
            encodings = ["utf-8", "latin-1", "cp1252"]
            for enc in encodings:
                try:
                    content = path.read_text(encoding=enc)
                    return {
                        "success": True,
                        "path": str(path),
                        "content": content,
                        "lines": content.count("\n"),
                        "size_kb": round(size / 1024, 2),
                        "encoding": enc,
                    }
                except UnicodeDecodeError:
                    continue

            return {"success": False, "error": "Binary file — cannot read as text."}

        except PermissionError:
            return {"success": False, "error": "Permission denied."}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_files(self, directory: str = "~", pattern: str = "*") -> dict:
        """List files in a directory."""
        directory = Path(directory).expanduser().resolve()
        if not directory.exists():
            return {"success": False, "error": f"Directory not found: {directory}"}
        if not directory.is_dir():
            return {"success": False, "error": f"Not a directory: {directory}"}

        try:
            files = []
            for item in sorted(directory.iterdir()):
                try:
                    stat = item.stat()
                    files.append({
                        "name": item.name,
                        "type": "dir" if item.is_dir() else "file",
                        "size_kb": round(stat.st_size / 1024, 2),
                        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        "extension": item.suffix.lower() if item.is_file() else "",
                    })
                except PermissionError:
                    pass

            return {
                "success": True,
                "directory": str(directory),
                "count": len(files),
                "files": files[:100],  # Cap at 100
            }
        except PermissionError:
            return {"success": False, "error": "Permission denied."}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def search_files(self, query: str, directory: str = "~", recursive: bool = True) -> dict:
        """Search for files by name."""
        directory = Path(directory).expanduser().resolve()
        results = []
        try:
            glob_method = directory.rglob if recursive else directory.glob
            for p in glob_method(f"*{query}*"):
                try:
                    results.append({
                        "path": str(p),
                        "name": p.name,
                        "type": "dir" if p.is_dir() else "file",
                        "size_kb": round(p.stat().st_size / 1024, 2) if p.is_file() else 0,
                    })
                except:
                    pass
                if len(results) >= 50:
                    break

            return {"success": True, "query": query, "results": results, "count": len(results)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def organize_folder(self, directory: str) -> dict:
        """
        Organize a folder by moving files into categorized subfolders.
        E.g., Downloads → Downloads/Images/, Downloads/Videos/, etc.
        """
        directory = Path(directory).expanduser().resolve()
        if not directory.exists():
            return {"success": False, "error": f"Directory not found: {directory}"}

        moved = {}
        errors = []

        for file in directory.iterdir():
            if file.is_dir():
                continue  # Skip subdirectories

            ext = file.suffix.lower()
            category = "Other"
            for cat, extensions in FILE_CATEGORIES.items():
                if ext in extensions:
                    category = cat
                    break

            target_dir = directory / category
            target_dir.mkdir(exist_ok=True)
            target_path = target_dir / file.name

            # Handle name conflicts
            counter = 1
            while target_path.exists():
                stem = file.stem
                target_path = target_dir / f"{stem}_{counter}{file.suffix}"
                counter += 1

            try:
                shutil.move(str(file), str(target_path))
                moved.setdefault(category, []).append(file.name)
            except Exception as e:
                errors.append(f"{file.name}: {e}")

        return {
            "success": True,
            "directory": str(directory),
            "moved": moved,
            "total_moved": sum(len(v) for v in moved.values()),
            "errors": errors,
        }

    def edit_file(self, path: str, content: str) -> dict:
        """Write/overwrite a file with new content."""
        path = Path(path).expanduser().resolve()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return {"success": True, "path": str(path), "size_kb": round(path.stat().st_size / 1024, 2)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_file(self, path: str, safe: bool = True) -> dict:
        """Delete a file (safe=True sends to trash)."""
        from pathlib import Path
        path = Path(path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": "File not found."}

        try:
            if safe:
                try:
                    import send2trash
                    send2trash.send2trash(str(path))
                    return {"success": True, "action": "sent_to_trash", "path": str(path)}
                except ImportError:
                    pass

            if path.is_dir():
                shutil.rmtree(str(path))
            else:
                path.unlink()
            return {"success": True, "action": "deleted_permanently", "path": str(path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def create_folder(self, path: str) -> dict:
        """Create a new folder."""
        path = Path(path).expanduser().resolve()
        try:
            path.mkdir(parents=True, exist_ok=True)
            return {"success": True, "path": str(path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_folder_size(self, directory: str) -> dict:
        """Get total size of a folder."""
        directory = Path(directory).expanduser().resolve()
        total = 0
        file_count = 0
        try:
            for p in directory.rglob("*"):
                if p.is_file():
                    try:
                        total += p.stat().st_size
                        file_count += 1
                    except:
                        pass
            return {
                "success": True,
                "path": str(directory),
                "size_mb": round(total / (1024 * 1024), 2),
                "size_gb": round(total / (1024 ** 3), 3),
                "files": file_count,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
