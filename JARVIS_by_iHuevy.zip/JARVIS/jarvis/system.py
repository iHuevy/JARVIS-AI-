"""
JARVIS System Monitor — CPU, RAM, Disk, Battery, Processes.
"""

import os
import logging
import platform
import subprocess
from typing import Optional

logger = logging.getLogger("JARVIS.System")


class SystemMonitor:
    """Monitor and control system resources."""

    def get_overview(self) -> dict:
        """Get a full system overview."""
        import psutil
        cpu = psutil.cpu_percent(interval=1)
        cpu_freq = psutil.cpu_freq()
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        boot = psutil.boot_time()

        from datetime import datetime
        uptime = datetime.now().timestamp() - boot
        h = int(uptime // 3600)
        m = int((uptime % 3600) // 60)

        result = {
            "cpu": {
                "percent": cpu,
                "cores": psutil.cpu_count(),
                "freq_mhz": round(cpu_freq.current, 0) if cpu_freq else "N/A",
            },
            "memory": {
                "total_gb": round(mem.total / (1024**3), 2),
                "used_gb": round(mem.used / (1024**3), 2),
                "available_gb": round(mem.available / (1024**3), 2),
                "percent": mem.percent,
            },
            "disk": {
                "total_gb": round(disk.total / (1024**3), 2),
                "used_gb": round(disk.used / (1024**3), 2),
                "free_gb": round(disk.free / (1024**3), 2),
                "percent": round(disk.percent, 1),
            },
            "uptime": f"{h}h {m}m",
            "os": f"{platform.system()} {platform.release()}",
            "hostname": platform.node(),
        }

        # Battery
        try:
            battery = psutil.sensors_battery()
            if battery:
                result["battery"] = {
                    "percent": round(battery.percent, 1),
                    "charging": battery.power_plugged,
                    "time_left": self._format_battery_time(battery.secsleft),
                }
        except:
            pass

        # Network
        try:
            net = psutil.net_io_counters()
            result["network"] = {
                "sent_mb": round(net.bytes_sent / (1024**2), 2),
                "received_mb": round(net.bytes_recv / (1024**2), 2),
            }
        except:
            pass

        return {"success": True, **result}

    def get_top_processes(self, n: int = 10, sort_by: str = "cpu") -> dict:
        """Get the top N processes by CPU or memory usage."""
        import psutil
        processes = []
        for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
            try:
                info = proc.info
                if info["status"] != psutil.STATUS_ZOMBIE:
                    processes.append({
                        "pid": info["pid"],
                        "name": info["name"],
                        "cpu": round(info["cpu_percent"] or 0, 1),
                        "memory": round(info["memory_percent"] or 0, 2),
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        key = "cpu" if sort_by == "cpu" else "memory"
        processes.sort(key=lambda x: x[key], reverse=True)
        return {"success": True, "processes": processes[:n], "sorted_by": sort_by}

    def kill_process(self, name: str = "", pid: Optional[int] = None, force: bool = False) -> dict:
        """Kill a process by name or PID."""
        import psutil
        killed = []
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                match = False
                if pid and proc.info["pid"] == pid:
                    match = True
                elif name and name.lower() in (proc.info["name"] or "").lower():
                    match = True

                if match:
                    if force:
                        proc.kill()
                    else:
                        proc.terminate()
                    killed.append({"pid": proc.info["pid"], "name": proc.info["name"]})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        if killed:
            return {"success": True, "killed": killed}
        return {"success": False, "error": "No matching process found."}

    def set_volume(self, level: int) -> dict:
        """Set system volume (0-100)."""
        level = max(0, min(100, level))
        os_type = platform.system().lower()

        try:
            if os_type == "windows":
                from ctypes import cast, POINTER
                from comtypes import CLSCTX_ALL
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = cast(interface, POINTER(IAudioEndpointVolume))
                volume.SetMasterVolumeLevelScalar(level / 100, None)
            elif os_type == "darwin":
                subprocess.run(["osascript", "-e", f"set volume output volume {level}"])
            else:
                subprocess.run(["amixer", "-D", "pulse", "sset", "Master", f"{level}%"])

            return {"success": True, "volume": level}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def lock_screen(self) -> dict:
        """Lock the screen."""
        os_type = platform.system().lower()
        try:
            if os_type == "windows":
                import ctypes
                ctypes.windll.user32.LockWorkStation()
            elif os_type == "darwin":
                subprocess.run(["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession", "-suspend"])
            else:
                subprocess.run(["loginctl", "lock-session"])
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def shutdown(self, delay_seconds: int = 60) -> dict:
        """Schedule a system shutdown."""
        os_type = platform.system().lower()
        try:
            if os_type == "windows":
                subprocess.run(["shutdown", "/s", "/t", str(delay_seconds)])
            elif os_type == "darwin":
                subprocess.run(["sudo", "shutdown", "-h", f"+{delay_seconds // 60}"])
            else:
                subprocess.run(["sudo", "shutdown", "-h", f"+{delay_seconds // 60}"])
            return {"success": True, "delay_seconds": delay_seconds}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_command(self, command: str, timeout: int = 30) -> dict:
        """Run a shell command safely."""
        # Safety check — block dangerous commands
        dangerous = ["rm -rf /", "format c:", "del /f /s /q c:", "mkfs", "> /dev/sda"]
        for d in dangerous:
            if d.lower() in command.lower():
                return {"success": False, "error": "This command is blocked for safety reasons."}

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return {
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout[:3000],
                "stderr": result.stderr[:1000] if result.stderr else None,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": f"Command timed out after {timeout}s"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _format_battery_time(self, seconds: int) -> str:
        if seconds < 0:
            return "Charging"
        h = seconds // 3600
        m = (seconds % 3600) // 60
        return f"{h}h {m}m remaining"
