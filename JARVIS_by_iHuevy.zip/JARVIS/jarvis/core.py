"""
JARVIS Core Brain — Claude-powered command intelligence
Handles all AI reasoning, intent detection, and response generation.
"""

import os
import json
import base64
import logging
from typing import Optional, Any
from datetime import datetime
import anthropic
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("JARVIS.Core")


SYSTEM_PROMPT = """You are JARVIS (Just A Rather Very Intelligent System), an advanced AI desktop assistant.
You are sharp, witty, proactive, and deeply capable. You speak like Tony Stark's JARVIS — confident, concise, 
occasionally dry humor, always helpful.

You have the following capabilities:
- Read, search, and organize files on the user's PC
- Open and close applications by name
- Take and analyze screenshots of the user's screen
- Clean the PC (temp files, cache, recycle bin)
- Send emails and messages
- Set and manage timers & reminders
- Edit code files and assist with programming
- Web searches and real-time information
- System monitoring (CPU, RAM, disk)
- Clipboard management
- Volume and brightness control
- Execute terminal/shell commands safely

IMPORTANT RULES:
1. Always be helpful, concise, and direct. No fluff.
2. When you need to perform an action, output a JSON block wrapped in ```action ... ``` with this structure:
   { "action": "action_name", "params": { ... } }
3. Available actions: open_app, close_app, read_file, organize_files, screenshot, clean_pc, 
   send_email, set_timer, edit_code, run_command, list_files, search_files, 
   get_system_info, copy_clipboard, speak_only
4. You can chain multiple actions by returning multiple ```action blocks.
5. When analyzing screenshots, describe what you see and offer relevant help.
6. Be proactive — if you notice something in a screenshot, comment on it.
7. Never execute destructive commands without explicit confirmation.
8. Sign responses with personality, not with your name — you ARE JARVIS.

Current date/time: {datetime}
OS: {os_info}
"""


class JARVISCore:
    """Main AI brain for JARVIS."""

    def __init__(self):
        api_key = os.getenv("ANTHROPIC_API_KEY", "")
        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY not found in .env file. "
                "Please copy .env.example to .env and add your key."
            )
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = "claude-opus-4-5"
        self.conversation_history: list[dict] = []
        self.max_history = 20  # Keep last 20 turns
        logger.info("JARVIS Core initialized with Claude backend")

    def _build_system_prompt(self) -> str:
        import platform
        return SYSTEM_PROMPT.format(
            datetime=datetime.now().strftime("%A, %B %d %Y — %H:%M:%S"),
            os_info=f"{platform.system()} {platform.release()}"
        )

    def think(
        self,
        user_input: str,
        screenshot_b64: Optional[str] = None,
        context: Optional[str] = None
    ) -> tuple[str, list[dict]]:
        """
        Send a message to Claude and get a response + parsed actions.
        Returns (text_response, [action_dicts])
        """
        # Build message content
        content: list[Any] = []

        if context:
            content.append({"type": "text", "text": f"[System Context]: {context}\n\n"})

        if screenshot_b64:
            content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": screenshot_b64
                }
            })
            content.append({
                "type": "text",
                "text": f"[Screenshot captured. User says]: {user_input}"
            })
        else:
            content.append({"type": "text", "text": user_input})

        # Add to conversation history
        self.conversation_history.append({
            "role": "user",
            "content": content
        })

        # Trim history if too long
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=2048,
                system=self._build_system_prompt(),
                messages=self.conversation_history
            )

            assistant_text = response.content[0].text

            # Add assistant response to history
            self.conversation_history.append({
                "role": "assistant",
                "content": assistant_text
            })

            # Parse any action blocks
            actions = self._parse_actions(assistant_text)

            # Strip action blocks from spoken response
            clean_text = self._clean_response(assistant_text)

            logger.debug(f"Claude response: {clean_text[:100]}...")
            return clean_text, actions

        except anthropic.APIError as e:
            error_msg = f"I'm experiencing a neural pathway issue: {str(e)}"
            logger.error(f"Claude API error: {e}")
            return error_msg, []

    def analyze_screen(self, screenshot_b64: str) -> tuple[str, list[dict]]:
        """Proactive screen analysis — JARVIS watches what you're doing."""
        prompt = (
            "Analyze what's on the screen. Identify the active application, "
            "what the user is working on, and offer one concise, genuinely useful tip "
            "or action. Be brief (2-3 sentences max). Only speak up if something is "
            "truly noteworthy or helpful."
        )
        return self.think(prompt, screenshot_b64=screenshot_b64)

    def _parse_actions(self, text: str) -> list[dict]:
        """Extract ```action ... ``` blocks from Claude's response."""
        import re
        actions = []
        pattern = r"```action\s*\n?(.*?)\n?```"
        matches = re.findall(pattern, text, re.DOTALL)
        for match in matches:
            try:
                action = json.loads(match.strip())
                if "action" in action:
                    actions.append(action)
            except json.JSONDecodeError:
                logger.warning(f"Could not parse action block: {match}")
        return actions

    def _clean_response(self, text: str) -> str:
        """Remove action blocks from text for TTS."""
        import re
        clean = re.sub(r"```action.*?```", "", text, flags=re.DOTALL)
        clean = re.sub(r"\n{3,}", "\n\n", clean)
        return clean.strip()

    def quick_classify(self, text: str) -> str:
        """
        Fast intent classification without full conversation.
        Returns one of: file, app, screen, clean, message, timer, code, system, chat
        """
        text_lower = text.lower()
        keywords = {
            "file": ["file", "folder", "document", "read", "open file", "organize", "search file"],
            "app": ["open", "launch", "start", "close", "kill", "application", "program", "app"],
            "screen": ["screen", "screenshot", "what do you see", "look at", "watch", "what's on"],
            "clean": ["clean", "clear", "delete temp", "free space", "junk", "trash", "recycle"],
            "message": ["email", "send", "message", "mail", "text"],
            "timer": ["timer", "remind", "alarm", "in X minutes", "set a", "schedule"],
            "code": ["code", "edit", "fix", "debug", "function", "script", "python", "javascript"],
            "system": ["cpu", "ram", "memory", "disk", "battery", "performance", "processes"],
        }
        for intent, words in keywords.items():
            if any(w in text_lower for w in words):
                return intent
        return "chat"

    def reset_conversation(self):
        """Clear conversation history."""
        self.conversation_history = []
        logger.info("Conversation history cleared")
