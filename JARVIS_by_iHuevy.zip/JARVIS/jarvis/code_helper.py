"""
JARVIS Code Helper — AI-powered code editing, debugging, and analysis.
"""

import os
import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger("JARVIS.Code")


class CodeHelper:
    """Handles code editing, running, and AI assistance."""

    SUPPORTED_LANGUAGES = {
        ".py":   "python",
        ".js":   "javascript",
        ".ts":   "typescript",
        ".jsx":  "jsx",
        ".tsx":  "tsx",
        ".html": "html",
        ".css":  "css",
        ".java": "java",
        ".c":    "c",
        ".cpp":  "cpp",
        ".go":   "go",
        ".rs":   "rust",
        ".rb":   "ruby",
        ".php":  "php",
        ".sh":   "bash",
        ".bat":  "batch",
        ".sql":  "sql",
        ".json": "json",
        ".yaml": "yaml",
        ".yml":  "yaml",
        ".md":   "markdown",
    }

    def read_code(self, path: str) -> dict:
        """Read a code file with syntax info."""
        path = Path(path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": f"File not found: {path}"}

        ext = path.suffix.lower()
        language = self.SUPPORTED_LANGUAGES.get(ext, "text")

        try:
            content = path.read_text(encoding="utf-8")
            lines = content.splitlines()
            return {
                "success": True,
                "path": str(path),
                "language": language,
                "lines": len(lines),
                "content": content,
                "size_kb": round(path.stat().st_size / 1024, 2),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_code(self, path: str, content: str, backup: bool = True) -> dict:
        """Write code to a file, optionally creating a backup."""
        path = Path(path).expanduser().resolve()

        # Create backup
        if backup and path.exists():
            backup_path = path.with_suffix(path.suffix + ".bak")
            try:
                import shutil
                shutil.copy2(str(path), str(backup_path))
            except Exception as e:
                logger.warning(f"Backup failed: {e}")

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return {
                "success": True,
                "path": str(path),
                "lines": content.count("\n"),
                "backup": str(path.with_suffix(path.suffix + ".bak")) if backup else None,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def apply_patch(self, path: str, old_code: str, new_code: str) -> dict:
        """Replace a specific code block in a file."""
        path = Path(path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": "File not found."}

        try:
            content = path.read_text(encoding="utf-8")
            if old_code not in content:
                return {"success": False, "error": "Original code block not found in file."}

            new_content = content.replace(old_code, new_code, 1)
            path.write_text(new_content, encoding="utf-8")
            return {"success": True, "path": str(path), "changed": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_python(self, path: str, timeout: int = 30) -> dict:
        """Run a Python script and capture output."""
        path = Path(path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": "File not found."}
        if path.suffix != ".py":
            return {"success": False, "error": "Not a Python file."}

        try:
            result = subprocess.run(
                ["python", str(path)],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=str(path.parent)
            )
            return {
                "success": result.returncode == 0,
                "returncode": result.returncode,
                "stdout": result.stdout[:3000],
                "stderr": result.stderr[:3000],
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": f"Script timed out after {timeout}s"}
        except FileNotFoundError:
            return {"success": False, "error": "Python interpreter not found."}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_snippet(self, code: str, language: str = "python") -> dict:
        """Run a code snippet and return output."""
        if language != "python":
            return {"success": False, "error": f"Direct execution of {language} not yet supported."}

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            f.write(code)
            tmp_path = f.name

        try:
            result = subprocess.run(
                ["python", tmp_path],
                capture_output=True,
                text=True,
                timeout=15
            )
            return {
                "success": result.returncode == 0,
                "output": result.stdout[:2000],
                "errors": result.stderr[:1000] if result.stderr else None,
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Code timed out after 15s"}
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def open_in_editor(self, path: str, editor: Optional[str] = None) -> dict:
        """Open a file in the system's code editor."""
        path = Path(path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": "File not found."}

        editors = {
            "windows": ["code", "notepad++", "notepad"],
            "darwin":  ["code", "sublime_text", "open"],
            "linux":   ["code", "gedit", "nano"],
        }

        import platform
        os_type = platform.system().lower()

        if editor:
            candidates = [editor]
        else:
            candidates = editors.get(os_type, ["code"])

        for ed in candidates:
            try:
                subprocess.Popen([ed, str(path)],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
                return {"success": True, "editor": ed, "path": str(path)}
            except FileNotFoundError:
                continue

        return {"success": False, "error": "No suitable editor found."}

    def get_code_stats(self, directory: str) -> dict:
        """Get code statistics for a project directory."""
        directory = Path(directory).expanduser().resolve()
        if not directory.exists():
            return {"success": False, "error": "Directory not found."}

        stats = {}
        total_lines = 0
        total_files = 0

        for file in directory.rglob("*"):
            if file.is_file() and file.suffix in self.SUPPORTED_LANGUAGES:
                lang = self.SUPPORTED_LANGUAGES[file.suffix]
                try:
                    lines = len(file.read_text(encoding="utf-8", errors="ignore").splitlines())
                    stats.setdefault(lang, {"files": 0, "lines": 0})
                    stats[lang]["files"] += 1
                    stats[lang]["lines"] += lines
                    total_lines += lines
                    total_files += 1
                except:
                    pass

        return {
            "success": True,
            "directory": str(directory),
            "total_files": total_files,
            "total_lines": total_lines,
            "by_language": stats,
        }
