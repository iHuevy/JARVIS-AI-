"""
JARVIS Voice Module — Text-to-Speech & Speech-to-Text
Handles all audio I/O for the assistant.
"""

import os
import logging
import threading
import queue
from typing import Optional, Callable

logger = logging.getLogger("JARVIS.Voice")


class VoiceEngine:
    """Manages TTS and STT for JARVIS."""

    def __init__(self):
        self.tts_engine = None
        self.recognizer = None
        self.microphone = None
        self.is_listening = False
        self.is_speaking = False
        self.speech_queue: queue.Queue = queue.Queue()
        self.wake_word = os.getenv("WAKE_WORD", "jarvis").lower()
        self.voice_rate = int(os.getenv("VOICE_RATE", "175"))
        self.voice_volume = float(os.getenv("VOICE_VOLUME", "1.0"))
        self._init_tts()
        self._init_stt()
        # Start background speech worker
        self._speech_thread = threading.Thread(target=self._speech_worker, daemon=True)
        self._speech_thread.start()

    def _init_tts(self):
        """Initialize pyttsx3 TTS engine."""
        try:
            import pyttsx3
            self.tts_engine = pyttsx3.init()
            self.tts_engine.setProperty("rate", self.voice_rate)
            self.tts_engine.setProperty("volume", self.voice_volume)

            # Try to set a good voice
            voices = self.tts_engine.getProperty("voices")
            if voices:
                voice_id = int(os.getenv("VOICE_ID", "0"))
                if voice_id < len(voices):
                    self.tts_engine.setProperty("voice", voices[voice_id].id)

            logger.info("TTS engine initialized (pyttsx3)")
        except ImportError:
            logger.warning("pyttsx3 not installed — TTS disabled. Run: pip install pyttsx3")
            self.tts_engine = None
        except Exception as e:
            logger.error(f"TTS init failed: {e}")
            self.tts_engine = None

    def _init_stt(self):
        """Initialize SpeechRecognition."""
        try:
            import speech_recognition as sr
            self.recognizer = sr.Recognizer()
            self.recognizer.energy_threshold = 300
            self.recognizer.dynamic_energy_threshold = True
            self.recognizer.pause_threshold = 0.8
            self.microphone = sr.Microphone()
            # Calibrate for ambient noise
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
            logger.info("STT engine initialized (SpeechRecognition)")
        except ImportError:
            logger.warning("SpeechRecognition not installed — STT disabled.")
            self.recognizer = None
        except Exception as e:
            logger.error(f"STT init failed: {e}")
            self.recognizer = None

    def speak(self, text: str, priority: bool = False):
        """Queue text for speech output."""
        if not text:
            return
        if priority:
            # Clear queue and speak immediately
            while not self.speech_queue.empty():
                try:
                    self.speech_queue.get_nowait()
                except:
                    pass
        self.speech_queue.put(text)

    def _speech_worker(self):
        """Background thread to process speech queue."""
        while True:
            try:
                text = self.speech_queue.get(timeout=0.5)
                self._speak_sync(text)
                self.speech_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Speech worker error: {e}")

    def _speak_sync(self, text: str):
        """Synchronously speak text."""
        self.is_speaking = True
        try:
            if self.tts_engine:
                # Clean text for speech (remove markdown, emojis, etc.)
                clean = self._clean_for_speech(text)
                self.tts_engine.say(clean)
                self.tts_engine.runAndWait()
            else:
                # Fallback: print to console
                print(f"[JARVIS]: {text}")
        except Exception as e:
            logger.error(f"Speech error: {e}")
            print(f"[JARVIS]: {text}")
        finally:
            self.is_speaking = False

    def listen(self, timeout: int = 10, phrase_limit: int = 15) -> Optional[str]:
        """
        Listen for speech and return transcribed text.
        Returns None if nothing heard or error.
        """
        if not self.recognizer or not self.microphone:
            return self._listen_fallback()

        import speech_recognition as sr
        try:
            with self.microphone as source:
                logger.debug("Listening...")
                audio = self.recognizer.listen(
                    source,
                    timeout=timeout,
                    phrase_time_limit=phrase_limit
                )

            # Try Google first, fall back to offline
            try:
                text = self.recognizer.recognize_google(audio)
                logger.info(f"Heard: {text}")
                return text
            except sr.UnknownValueError:
                return None
            except sr.RequestError:
                # Offline fallback with sphinx if available
                try:
                    text = self.recognizer.recognize_sphinx(audio)
                    return text
                except:
                    return None

        except sr.WaitTimeoutError:
            return None
        except Exception as e:
            logger.error(f"Listen error: {e}")
            return None

    def listen_for_wake_word(self, callback: Callable[[str], None]):
        """
        Continuously listen for wake word in background.
        When detected, calls callback with the full phrase.
        """
        import speech_recognition as sr
        if not self.recognizer or not self.microphone:
            logger.warning("STT not available for wake word detection")
            return

        def _listen_loop():
            self.is_listening = True
            logger.info(f"Wake word listening active. Say '{self.wake_word}' to activate.")
            while self.is_listening:
                try:
                    with self.microphone as source:
                        audio = self.recognizer.listen(source, timeout=3, phrase_time_limit=10)
                    try:
                        text = self.recognizer.recognize_google(audio).lower()
                        if self.wake_word in text:
                            # Extract command after wake word
                            command = text.split(self.wake_word, 1)[-1].strip()
                            if not command:
                                self.speak("Yes? How can I help?")
                                # Listen for the follow-up
                                command = self.listen(timeout=8)
                            if command:
                                callback(command)
                    except sr.UnknownValueError:
                        pass
                    except sr.RequestError as e:
                        logger.warning(f"STT API error: {e}")
                except sr.WaitTimeoutError:
                    pass
                except Exception as e:
                    logger.error(f"Wake word loop error: {e}")

        thread = threading.Thread(target=_listen_loop, daemon=True)
        thread.start()
        return thread

    def stop_listening(self):
        self.is_listening = False

    def _listen_fallback(self) -> Optional[str]:
        """Text input fallback when microphone unavailable."""
        try:
            return input("You: ").strip() or None
        except EOFError:
            return None

    def _clean_for_speech(self, text: str) -> str:
        """Remove markdown and special chars for clean TTS."""
        import re
        # Remove markdown
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
        text = re.sub(r"\*(.+?)\*", r"\1", text)
        text = re.sub(r"`(.+?)`", r"\1", text)
        text = re.sub(r"#{1,6}\s", "", text)
        text = re.sub(r"\[(.+?)\]\(.+?\)", r"\1", text)
        # Remove emoji-like unicode sequences
        text = re.sub(r"[^\x00-\x7F]+", " ", text)
        # Clean up whitespace
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def list_voices(self) -> list[str]:
        """Return available TTS voices."""
        if not self.tts_engine:
            return []
        voices = self.tts_engine.getProperty("voices")
        return [f"{i}: {v.name}" for i, v in enumerate(voices)]

    def set_rate(self, rate: int):
        """Change speech rate on-the-fly."""
        self.voice_rate = rate
        if self.tts_engine:
            self.tts_engine.setProperty("rate", rate)
