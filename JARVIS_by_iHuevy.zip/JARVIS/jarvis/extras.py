"""
JARVIS Extras — Bonus features: jokes, productivity, news, fun tools.
"""

import os
import time
import random
import logging
import platform
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("JARVIS.Extras")


class JARVISExtras:
    """
    Bonus JARVIS capabilities beyond the core modules.
    Each method is standalone and safe to call independently.
    """

    # ── Productivity ──────────────────────────────────────────────────────────
    def take_note(self, content: str, title: Optional[str] = None) -> dict:
        """Save a quick note to ~/Documents/JARVIS_Notes/"""
        notes_dir = Path.home() / "Documents" / "JARVIS_Notes"
        notes_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"{title or 'note'}_{timestamp}.txt".replace(" ", "_")
        note_path = notes_dir / filename

        full_content = f"[JARVIS Note — {datetime.now().strftime('%B %d, %Y %H:%M')}]\n{'='*40}\n{content}\n"
        note_path.write_text(full_content, encoding="utf-8")

        logger.info(f"Note saved: {note_path}")
        return {"success": True, "path": str(note_path), "title": filename}

    def list_notes(self) -> dict:
        """List all saved notes."""
        notes_dir = Path.home() / "Documents" / "JARVIS_Notes"
        if not notes_dir.exists():
            return {"success": True, "notes": [], "count": 0}

        notes = []
        for f in sorted(notes_dir.iterdir(), reverse=True):
            if f.suffix == ".txt":
                notes.append({
                    "name": f.stem,
                    "path": str(f),
                    "modified": datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
                    "size_kb": round(f.stat().st_size / 1024, 2),
                })
        return {"success": True, "notes": notes[:20], "count": len(notes)}

    def pomodoro(self, work_minutes: int = 25, break_minutes: int = 5, speak_fn=None) -> dict:
        """
        Start a Pomodoro timer session.
        Runs in background — notifies when work/break period ends.
        """
        import threading

        def _run():
            msg = f"Pomodoro started. Work for {work_minutes} minutes."
            if speak_fn:
                speak_fn(msg)
            else:
                print(f"[JARVIS] {msg}")

            time.sleep(work_minutes * 60)

            msg = f"Work session complete! Take a {break_minutes}-minute break."
            if speak_fn:
                speak_fn(msg)
            else:
                print(f"[JARVIS] {msg}")

            try:
                from jarvis.messaging import MessagingHub
                MessagingHub().send_system_notification("JARVIS Pomodoro", msg)
            except:
                pass

            time.sleep(break_minutes * 60)

            msg = "Break over. Time to get back to work!"
            if speak_fn:
                speak_fn(msg)
            else:
                print(f"[JARVIS] {msg}")

        threading.Thread(target=_run, daemon=True).start()
        return {
            "success": True,
            "work_minutes": work_minutes,
            "break_minutes": break_minutes,
            "message": f"Pomodoro running: {work_minutes}m work + {break_minutes}m break",
        }

    def get_day_summary(self) -> dict:
        """Generate a daily productivity summary."""
        now = datetime.now()
        notes_dir = Path.home() / "Documents" / "JARVIS_Notes"
        today_notes = []

        if notes_dir.exists():
            today = now.strftime("%Y-%m-%d")
            for f in notes_dir.iterdir():
                if today in f.name and f.suffix == ".txt":
                    today_notes.append(f.stem)

        return {
            "success": True,
            "date": now.strftime("%A, %B %d %Y"),
            "time": now.strftime("%H:%M"),
            "day_of_week": now.strftime("%A"),
            "notes_today": len(today_notes),
            "notes_titles": today_notes,
            "week_number": now.isocalendar()[1],
        }

    # ── System Extras ──────────────────────────────────────────────────────────
    def get_startup_programs(self) -> dict:
        """List programs that run at startup (Windows)."""
        os_type = platform.system().lower()
        if os_type != "windows":
            return {"success": False, "error": "Startup program list only available on Windows."}

        try:
            result = subprocess.run(
                ["reg", "query", r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"],
                capture_output=True, text=True
            )
            user_result = subprocess.run(
                ["reg", "query", r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"],
                capture_output=True, text=True
            )

            programs = []
            for line in (result.stdout + user_result.stdout).splitlines():
                line = line.strip()
                if line and "REG_SZ" in line:
                    parts = line.split("REG_SZ")
                    if len(parts) == 2:
                        programs.append({
                            "name": parts[0].strip(),
                            "path": parts[1].strip(),
                        })

            return {"success": True, "startup_programs": programs, "count": len(programs)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def check_internet(self) -> dict:
        """Check internet connectivity and speed."""
        import urllib.request
        hosts = [
            ("Google", "https://google.com"),
            ("Anthropic", "https://anthropic.com"),
            ("Cloudflare", "https://1.1.1.1"),
        ]
        results = {}
        for name, url in hosts:
            try:
                start = time.time()
                urllib.request.urlopen(url, timeout=4)
                ms = round((time.time() - start) * 1000, 1)
                results[name] = {"online": True, "ping_ms": ms}
            except:
                results[name] = {"online": False, "ping_ms": None}

        online = any(v["online"] for v in results.values())
        return {
            "success": True,
            "internet": online,
            "hosts": results,
        }

    def get_installed_apps(self) -> dict:
        """Get list of installed applications (cross-platform)."""
        os_type = platform.system().lower()
        apps = []

        try:
            if os_type == "windows":
                result = subprocess.run(
                    ["powershell", "-Command",
                     "Get-ItemProperty HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* | Select-Object DisplayName, DisplayVersion | Where-Object { $_.DisplayName } | ConvertTo-Json"],
                    capture_output=True, text=True, timeout=15
                )
                import json
                data = json.loads(result.stdout)
                if isinstance(data, list):
                    apps = [{"name": d.get("DisplayName", ""), "version": d.get("DisplayVersion", "")} for d in data if d.get("DisplayName")]
                elif isinstance(data, dict):
                    apps = [{"name": data.get("DisplayName", ""), "version": data.get("DisplayVersion", "")}]

            elif os_type == "darwin":
                result = subprocess.run(
                    ["ls", "/Applications"],
                    capture_output=True, text=True
                )
                apps = [{"name": a.replace(".app", ""), "version": ""} for a in result.stdout.splitlines() if a.endswith(".app")]

            else:
                result = subprocess.run(
                    ["dpkg", "--list"],
                    capture_output=True, text=True
                )
                for line in result.stdout.splitlines():
                    if line.startswith("ii"):
                        parts = line.split()
                        if len(parts) >= 3:
                            apps.append({"name": parts[1], "version": parts[2]})

            return {"success": True, "apps": apps[:50], "total": len(apps)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ── Fun / Personality ──────────────────────────────────────────────────────
    def tell_joke(self) -> str:
        """Return a random tech/AI joke."""
        jokes = [
            "Why do programmers prefer dark mode? Because light attracts bugs.",
            "I told my AI to be more human. Now it makes excuses and procrastinates.",
            "There are 10 types of people: those who understand binary, and those who don't.",
            "A SQL query walks into a bar, walks up to two tables, and asks... 'Can I join you?'",
            "Why don't scientists trust atoms? Because they make up everything.",
            "I asked the computer to sing me a song. It gave me an album... of error messages.",
            "Why was the developer unhappy at their job? They wanted arrays.",
            "To understand recursion, you must first understand recursion.",
            "My password is 'incorrect'. So when I forget it, the system says: 'Your password is incorrect.'",
            "A byte walks into a bar and orders a pint. The bartender asks: 'Are you alright?' The byte says: 'No, I'm feeling a bit off.'",
        ]
        return random.choice(jokes)

    def get_motivation(self) -> str:
        """Return a motivational quote."""
        quotes = [
            "The best way to predict the future is to invent it. — Alan Kay",
            "Any sufficiently advanced technology is indistinguishable from magic. — Arthur C. Clarke",
            "The computer was born to solve problems that did not exist before. — Bill Gates",
            "Code is like humor. When you have to explain it, it's bad. — Cory House",
            "First, solve the problem. Then, write the code. — John Johnson",
            "Make it work, make it right, make it fast. — Kent Beck",
            "Simplicity is the soul of efficiency. — Austin Freeman",
            "The function of good software is to make the complex appear simple. — Grady Booch",
            "Talk is cheap. Show me the code. — Linus Torvalds",
            "It always seems impossible until it's done. — Nelson Mandela",
        ]
        return random.choice(quotes)

    def calculate(self, expression: str) -> dict:
        """Safe math expression evaluator."""
        try:
            # Only allow safe math operations
            allowed = set("0123456789+-*/.() %")
            clean_expr = expression.replace("^", "**").replace("x", "*")
            if not all(c in allowed or c.isspace() for c in clean_expr.replace("**", "")):
                return {"success": False, "error": "Only numeric expressions are allowed."}

            result = eval(clean_expr, {"__builtins__": {}}, {})
            return {
                "success": True,
                "expression": expression,
                "result": result,
                "formatted": f"{expression} = {result}",
            }
        except ZeroDivisionError:
            return {"success": False, "error": "Division by zero."}
        except Exception as e:
            return {"success": False, "error": f"Could not evaluate: {e}"}

    def set_wallpaper(self, image_path: str) -> dict:
        """Set desktop wallpaper."""
        path = Path(image_path).expanduser().resolve()
        if not path.exists():
            return {"success": False, "error": "Image file not found."}

        os_type = platform.system().lower()
        try:
            if os_type == "windows":
                import ctypes
                ctypes.windll.user32.SystemParametersInfoW(20, 0, str(path), 3)
            elif os_type == "darwin":
                subprocess.run([
                    "osascript", "-e",
                    f'tell application "Finder" to set desktop picture to POSIX file "{path}"'
                ])
            else:
                subprocess.run(["gsettings", "set", "org.gnome.desktop.background",
                                "picture-uri", f"file://{path}"])
            return {"success": True, "path": str(path)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def open_url(self, url: str) -> dict:
        """Open a URL in the default browser."""
        try:
            import webbrowser
            if not url.startswith(("http://", "https://")):
                url = "https://" + url
            webbrowser.open(url)
            return {"success": True, "url": url}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_public_ip(self) -> dict:
        """Get public IP address."""
        import urllib.request
        try:
            with urllib.request.urlopen("https://api.ipify.org?format=json", timeout=5) as r:
                import json
                data = json.loads(r.read())
            return {"success": True, "ip": data["ip"]}
        except Exception as e:
            return {"success": False, "error": str(e)}
