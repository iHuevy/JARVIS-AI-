"""
JARVIS Action Dispatcher — Routes Claude's action commands to the correct module.
"""

import logging
import json
from typing import Any, Optional, Callable

logger = logging.getLogger("JARVIS.Dispatcher")


class ActionDispatcher:
    """
    Takes action dicts from Claude and dispatches them to the right module.
    All modules are lazy-loaded to keep startup fast.
    """

    def __init__(self, speak_callback: Optional[Callable[[str], None]] = None):
        self._speak = speak_callback
        self._file_mgr = None
        self._app_ctrl = None
        self._screen = None
        self._cleaner = None
        self._messaging = None
        self._timers = None
        self._code = None
        self._system = None
        self._web = None
        self._extras = None

    # ── Lazy loaders ───────────────────────────────────────────────────────────
    @property
    def files(self):
        if not self._file_mgr:
            from jarvis.files import FileManager
            self._file_mgr = FileManager()
        return self._file_mgr

    @property
    def apps(self):
        if not self._app_ctrl:
            from jarvis.apps import AppController
            self._app_ctrl = AppController()
        return self._app_ctrl

    @property
    def screen(self):
        if not self._screen:
            from jarvis.screen import ScreenWatcher
            self._screen = ScreenWatcher()
        return self._screen

    @property
    def cleaner(self):
        if not self._cleaner:
            from jarvis.cleaner import PCCleaner
            self._cleaner = PCCleaner()
        return self._cleaner

    @property
    def messaging(self):
        if not self._messaging:
            from jarvis.messaging import MessagingHub
            self._messaging = MessagingHub()
        return self._messaging

    @property
    def timers(self):
        if not self._timers:
            from jarvis.timers import TimerManager
            self._timers = TimerManager(speak_callback=self._speak)
        return self._timers

    @property
    def code(self):
        if not self._code:
            from jarvis.code_helper import CodeHelper
            self._code = CodeHelper()
        return self._code

    @property
    def system(self):
        if not self._system:
            from jarvis.system import SystemMonitor
            self._system = SystemMonitor()
        return self._system

    @property
    def web(self):
        if not self._web:
            from jarvis.web_search import WebSearcher
            self._web = WebSearcher()
        return self._web

    @property
    def extras(self):
        if not self._extras:
            from jarvis.extras import JARVISExtras
            self._extras = JARVISExtras()
        return self._extras

    # ── Main dispatch ──────────────────────────────────────────────────────────
    def dispatch(self, action: dict) -> dict:
        """
        Dispatch a single action dict. Returns result dict.
        Action format: {"action": "action_name", "params": {...}}
        """
        action_name = action.get("action", "").lower()
        params = action.get("params", {})

        logger.info(f"Dispatching action: {action_name} with params: {list(params.keys())}")

        dispatch_map = {
            # Files
            "read_file":      lambda p: self.files.read_file(p.get("path", "")),
            "list_files":     lambda p: self.files.list_files(p.get("directory", "~"), p.get("pattern", "*")),
            "search_files":   lambda p: self.files.search_files(p.get("query", ""), p.get("directory", "~")),
            "organize_files": lambda p: self.files.organize_folder(p.get("directory", "~/Downloads")),
            "edit_file":      lambda p: self.files.edit_file(p.get("path", ""), p.get("content", "")),
            "delete_file":    lambda p: self.files.delete_file(p.get("path", ""), p.get("safe", True)),
            "create_folder":  lambda p: self.files.create_folder(p.get("path", "")),
            "folder_size":    lambda p: self.files.get_folder_size(p.get("directory", "~")),

            # Apps
            "open_app":       lambda p: self.apps.open_app(p.get("name", "")),
            "close_app":      lambda p: self.apps.close_app(p.get("name", ""), p.get("force", False)),
            "list_apps":      lambda p: self.apps.list_running_apps(),
            "app_info":       lambda p: self.apps.get_app_info(p.get("name", "")),

            # Screen
            "screenshot":     lambda p: self._take_screenshot(p),
            "click":          lambda p: self.screen.click(p.get("x", 0), p.get("y", 0)),
            "type_text":      lambda p: self.screen.type_text(p.get("text", "")),
            "hotkey":         lambda p: self.screen.hotkey(*p.get("keys", [])),
            "focus_window":   lambda p: self.screen.focus_window(p.get("title", "")),
            "get_windows":    lambda p: {"windows": self.screen.get_window_list()},

            # Cleaning
            "clean_pc":       lambda p: self.cleaner.clean(p.get("categories")),
            "scan_junk":      lambda p: self.cleaner.scan(),
            "disk_info":      lambda p: self.cleaner.get_disk_info(),
            "clean_browser":  lambda p: self.cleaner.clean_browser_cache(p.get("browser", "all")),

            # Messaging
            "send_email":     lambda p: self.messaging.send_email(
                p.get("to", ""), p.get("subject", ""), p.get("body", ""), p.get("cc")
            ),
            "notify":         lambda p: self.messaging.send_system_notification(
                p.get("title", "JARVIS"), p.get("message", "")
            ),
            "open_whatsapp":  lambda p: self.messaging.open_whatsapp(
                p.get("phone", ""), p.get("message", "")
            ),
            "copy_clipboard": lambda p: self.messaging.copy_to_clipboard(p.get("text", "")),
            "get_clipboard":  lambda p: self.messaging.get_clipboard(),

            # Timers
            "set_timer":      lambda p: self.timers.set_timer(
                p.get("seconds", 0), p.get("minutes", 0), p.get("hours", 0), p.get("label", "Timer")
            ),
            "set_reminder":   lambda p: self.timers.set_reminder(
                p.get("message", ""), p.get("at"), p.get("in_minutes", 0)
            ),
            "list_timers":    lambda p: self.timers.list_timers(),
            "cancel_timer":   lambda p: self.timers.cancel_timer(p.get("id", "")),

            # Code
            "read_code":      lambda p: self.code.read_code(p.get("path", "")),
            "write_code":     lambda p: self.code.write_code(p.get("path", ""), p.get("content", "")),
            "run_python":     lambda p: self.code.run_python(p.get("path", "")),
            "run_snippet":    lambda p: self.code.run_snippet(p.get("code", ""), p.get("language", "python")),
            "open_editor":    lambda p: self.code.open_in_editor(p.get("path", "")),
            "code_stats":     lambda p: self.code.get_code_stats(p.get("directory", ".")),
            "apply_patch":    lambda p: self.code.apply_patch(
                p.get("path", ""), p.get("old", ""), p.get("new", "")
            ),

            # System
            "get_system_info": lambda p: self.system.get_overview(),
            "top_processes":   lambda p: self.system.get_top_processes(p.get("n", 10), p.get("sort", "cpu")),
            "kill_process":    lambda p: self.system.kill_process(p.get("name", ""), p.get("pid")),
            "set_volume":      lambda p: self.system.set_volume(int(p.get("level", 50))),
            "lock_screen":     lambda p: self.system.lock_screen(),
            "run_command":     lambda p: self.system.run_command(p.get("command", "")),

            # Web
            "web_search":      lambda p: self.web.search(p.get("query", ""), p.get("max_results", 5)),
            "fetch_page":      lambda p: self.web.fetch_page(p.get("url", "")),
            "get_weather":     lambda p: self.web.get_weather(p.get("location", "")),
            "define_word":     lambda p: self.web.define_word(p.get("word", "")),
            "convert_currency":lambda p: self.web.currency_convert(
                p.get("amount", 1), p.get("from", "USD"), p.get("to", "EUR")
            ),

            # Extras
            "take_note":       lambda p: self.extras.take_note(p.get("content", ""), p.get("title")),
            "list_notes":      lambda p: self.extras.list_notes(),
            "calculate":       lambda p: self.extras.calculate(p.get("expression", "")),
            "tell_joke":       lambda p: {"success": True, "joke": self.extras.tell_joke()},
            "motivate":        lambda p: {"success": True, "quote": self.extras.get_motivation()},
            "pomodoro":        lambda p: self.extras.pomodoro(
                p.get("work_minutes", 25), p.get("break_minutes", 5), self._speak
            ),
            "open_url":        lambda p: self.extras.open_url(p.get("url", "")),
            "check_internet":  lambda p: self.extras.check_internet(),
            "day_summary":     lambda p: self.extras.get_day_summary(),
            "set_wallpaper":   lambda p: self.extras.set_wallpaper(p.get("path", "")),

            # Meta
            "speak_only": lambda p: {"success": True, "spoken": True},
        }

        handler = dispatch_map.get(action_name)
        if handler:
            try:
                result = handler(params)
                logger.debug(f"Action {action_name} result: {str(result)[:200]}")
                return result
            except Exception as e:
                logger.error(f"Action {action_name} failed: {e}")
                return {"success": False, "action": action_name, "error": str(e)}
        else:
            logger.warning(f"Unknown action: {action_name}")
            return {"success": False, "error": f"Unknown action: '{action_name}'"}

    def dispatch_all(self, actions: list[dict]) -> list[dict]:
        """Dispatch a list of actions and return all results."""
        return [self.dispatch(a) for a in actions]

    def _take_screenshot(self, params: dict) -> dict:
        """Take a screenshot and optionally save it."""
        region = params.get("region")
        save = params.get("save", False)
        b64 = self.screen.capture(region)
        result = {"success": b64 is not None, "captured": b64 is not None}
        if save and b64:
            path = self.screen.save_screenshot(params.get("filename"))
            result["saved_to"] = path
        return result
