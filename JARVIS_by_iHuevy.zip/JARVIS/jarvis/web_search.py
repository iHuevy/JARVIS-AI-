"""
JARVIS Web Search Module — Real-time web lookups and information retrieval.
Uses DuckDuckGo (no API key required) + optional Google fallback.
"""

import logging
import urllib.request
import urllib.parse
import json
import re
from typing import Optional

logger = logging.getLogger("JARVIS.WebSearch")


class WebSearcher:
    """Handles web searches and URL fetching for JARVIS."""

    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
    }

    def search(self, query: str, max_results: int = 5) -> dict:
        """
        Search DuckDuckGo Instant Answer API.
        No API key required.
        """
        try:
            encoded = urllib.parse.quote(query)
            url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_redirect=1&no_html=1"

            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            results = []

            # Abstract (main answer)
            if data.get("AbstractText"):
                results.append({
                    "title": data.get("Heading", query),
                    "snippet": data["AbstractText"],
                    "source": data.get("AbstractSource", ""),
                    "url": data.get("AbstractURL", ""),
                    "type": "answer",
                })

            # Related topics
            for topic in data.get("RelatedTopics", [])[:max_results]:
                if isinstance(topic, dict) and topic.get("Text"):
                    results.append({
                        "title": topic.get("Text", "")[:60],
                        "snippet": topic.get("Text", ""),
                        "url": topic.get("FirstURL", ""),
                        "type": "related",
                    })

            # Instant answer
            if data.get("Answer"):
                results.insert(0, {
                    "title": "Direct Answer",
                    "snippet": data["Answer"],
                    "url": "",
                    "type": "instant",
                })

            if results:
                return {
                    "success": True,
                    "query": query,
                    "results": results[:max_results],
                    "count": len(results),
                }

            # Fallback to HTML scrape
            return self._search_html(query, max_results)

        except Exception as e:
            logger.warning(f"DDG API failed: {e}, falling back to HTML")
            return self._search_html(query, max_results)

    def _search_html(self, query: str, max_results: int = 5) -> dict:
        """Fallback: scrape DuckDuckGo HTML results."""
        try:
            encoded = urllib.parse.quote(query)
            url = f"https://html.duckduckgo.com/html/?q={encoded}"

            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                html = resp.read().decode("utf-8", errors="ignore")

            # Parse result snippets
            results = []
            # Match result blocks
            snippet_pattern = re.compile(
                r'<a class="result__snippet"[^>]*>(.*?)</a>', re.DOTALL
            )
            title_pattern = re.compile(
                r'<a class="result__a"[^>]*>(.*?)</a>', re.DOTALL
            )
            snippets = snippet_pattern.findall(html)
            titles = title_pattern.findall(html)

            for i, (title, snippet) in enumerate(zip(titles, snippets)):
                if i >= max_results:
                    break
                clean_title = re.sub(r"<[^>]+>", "", title).strip()
                clean_snippet = re.sub(r"<[^>]+>", "", snippet).strip()
                if clean_title and clean_snippet:
                    results.append({
                        "title": clean_title,
                        "snippet": clean_snippet,
                        "url": "",
                        "type": "result",
                    })

            if results:
                return {
                    "success": True,
                    "query": query,
                    "results": results,
                    "count": len(results),
                }

            return {"success": False, "error": "No results found.", "query": query}

        except Exception as e:
            logger.error(f"HTML search failed: {e}")
            return {"success": False, "error": str(e), "query": query}

    def fetch_page(self, url: str, max_chars: int = 3000) -> dict:
        """Fetch and extract text from a web page."""
        try:
            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                html = resp.read().decode("utf-8", errors="ignore")

            # Strip scripts and styles
            html = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL)
            html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL)

            # Extract text
            text = re.sub(r"<[^>]+>", " ", html)
            text = re.sub(r"\s+", " ", text).strip()
            text = text[:max_chars]

            return {"success": True, "url": url, "content": text, "length": len(text)}

        except Exception as e:
            return {"success": False, "url": url, "error": str(e)}

    def get_weather(self, location: str) -> dict:
        """Get weather for a location using wttr.in (no key needed)."""
        try:
            encoded = urllib.parse.quote(location)
            url = f"https://wttr.in/{encoded}?format=j1"

            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read())

            current = data["current_condition"][0]
            weather = data["weather"][0]

            return {
                "success": True,
                "location": location,
                "temp_c": current["temp_C"],
                "temp_f": current["temp_F"],
                "feels_like_c": current["FeelsLikeC"],
                "description": current["weatherDesc"][0]["value"],
                "humidity": current["humidity"],
                "wind_kmph": current["windspeedKmph"],
                "uv_index": current["uvIndex"],
                "max_temp_c": weather["maxtempC"],
                "min_temp_c": weather["mintempC"],
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def define_word(self, word: str) -> dict:
        """Get definition of a word using Free Dictionary API."""
        try:
            url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{urllib.parse.quote(word)}"
            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read())

            entry = data[0]
            meanings = []
            for meaning in entry.get("meanings", [])[:3]:
                defs = [d["definition"] for d in meaning.get("definitions", [])[:2]]
                meanings.append({
                    "part_of_speech": meaning.get("partOfSpeech", ""),
                    "definitions": defs,
                })

            return {
                "success": True,
                "word": word,
                "phonetic": entry.get("phonetic", ""),
                "meanings": meanings,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_ip_info(self) -> dict:
        """Get current public IP and location."""
        try:
            req = urllib.request.Request("https://ipinfo.io/json", headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read())
            return {"success": True, **data}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def currency_convert(self, amount: float, from_cur: str, to_cur: str) -> dict:
        """Convert currency using a free API."""
        try:
            url = f"https://api.exchangerate-api.com/v4/latest/{from_cur.upper()}"
            req = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read())

            rate = data["rates"].get(to_cur.upper())
            if rate is None:
                return {"success": False, "error": f"Currency '{to_cur}' not found."}

            converted = round(amount * rate, 4)
            return {
                "success": True,
                "from": f"{amount} {from_cur.upper()}",
                "to": f"{converted} {to_cur.upper()}",
                "rate": rate,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
