"""
JARVIS Screen Module — Capture, analyze, and interact with the screen.
JARVIS can see your screen and provide contextual assistance.
"""

import io
import base64
import logging
import threading
import time
from typing import Optional, Callable
from pathlib import Path
from datetime import datetime

logger = logging.getLogger("JARVIS.Screen")


class ScreenWatcher:
    """Captures and analyzes the user's screen."""

    def __init__(self):
        self.watching = False
        self.watch_interval = 10  # seconds
        self._last_screenshot: Optional[str] = None  # base64
        self._watch_thread: Optional[threading.Thread] = None

    def capture(self, region: Optional[tuple] = None) -> Optional[str]:
        """
        Take a screenshot and return as base64-encoded PNG.
        region: (x, y, width, height) or None for full screen.
        """
        try:
            import pyautogui
            from PIL import Image

            if region:
                screenshot = pyautogui.screenshot(region=region)
            else:
                screenshot = pyautogui.screenshot()

            # Resize for efficiency (Claude's vision works great at 1280px wide)
            max_width = 1280
            if screenshot.width > max_width:
                ratio = max_width / screenshot.width
                new_size = (max_width, int(screenshot.height * ratio))
                screenshot = screenshot.resize(new_size, Image.LANCZOS)

            # Convert to base64
            buffer = io.BytesIO()
            screenshot.save(buffer, format="PNG", optimize=True)
            b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
            self._last_screenshot = b64
            return b64

        except ImportError:
            logger.warning("pyautogui or Pillow not installed — screen capture disabled.")
            return None
        except Exception as e:
            logger.error(f"Screen capture error: {e}")
            return None

    def save_screenshot(self, filename: Optional[str] = None) -> str:
        """Save a screenshot to disk and return the path."""
        try:
            import pyautogui
            if filename is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"jarvis_screenshot_{timestamp}.png"

            path = Path.home() / "Pictures" / filename
            path.parent.mkdir(parents=True, exist_ok=True)

            screenshot = pyautogui.screenshot()
            screenshot.save(str(path))
            logger.info(f"Screenshot saved: {path}")
            return str(path)
        except Exception as e:
            logger.error(f"Save screenshot error: {e}")
            return ""

    def start_watching(self, callback: Callable[[str], None], interval: int = 10):
        """
        Start proactive screen watching.
        Periodically captures the screen and calls callback with analysis.
        """
        self.watching = True
        self.watch_interval = interval

        def _watch_loop():
            while self.watching:
                time.sleep(self.watch_interval)
                if not self.watching:
                    break
                b64 = self.capture()
                if b64:
                    callback(b64)

        self._watch_thread = threading.Thread(target=_watch_loop, daemon=True)
        self._watch_thread.start()
        logger.info(f"Screen watching started (interval: {interval}s)")

    def stop_watching(self):
        """Stop proactive screen watching."""
        self.watching = False
        logger.info("Screen watching stopped")

    def click(self, x: int, y: int):
        """Click at screen coordinates."""
        try:
            import pyautogui
            pyautogui.click(x, y)
            return {"success": True, "action": "click", "x": x, "y": y}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def type_text(self, text: str, interval: float = 0.05):
        """Type text as if from keyboard."""
        try:
            import pyautogui
            pyautogui.typewrite(text, interval=interval)
            return {"success": True, "action": "type", "text": text}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def hotkey(self, *keys):
        """Press a keyboard shortcut. E.g., hotkey('ctrl', 's')"""
        try:
            import pyautogui
            pyautogui.hotkey(*keys)
            return {"success": True, "action": "hotkey", "keys": keys}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def scroll(self, clicks: int = 3, direction: str = "down"):
        """Scroll the screen."""
        try:
            import pyautogui
            amount = clicks if direction == "up" else -clicks
            pyautogui.scroll(amount)
            return {"success": True, "action": "scroll", "direction": direction}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_window_list(self) -> list[str]:
        """Get list of open window titles."""
        try:
            import pygetwindow as gw
            return [w.title for w in gw.getAllWindows() if w.title]
        except ImportError:
            return []
        except Exception as e:
            logger.error(f"Window list error: {e}")
            return []

    def focus_window(self, title_keyword: str) -> dict:
        """Bring a window to focus by title keyword."""
        try:
            import pygetwindow as gw
            windows = [w for w in gw.getAllWindows() if title_keyword.lower() in w.title.lower()]
            if not windows:
                return {"success": False, "error": f"No window found with '{title_keyword}'"}
            windows[0].activate()
            return {"success": True, "window": windows[0].title}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_last_screenshot_b64(self) -> Optional[str]:
        """Return the most recent screenshot in base64."""
        return self._last_screenshot
