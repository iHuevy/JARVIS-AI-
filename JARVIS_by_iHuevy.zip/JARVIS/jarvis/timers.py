"""
JARVIS Timers Module — Set timers, alarms, and reminders.
"""

import time
import logging
import threading
import uuid
from datetime import datetime, timedelta
from typing import Callable, Optional
from dataclasses import dataclass, field

logger = logging.getLogger("JARVIS.Timers")


@dataclass
class TimerEntry:
    id: str
    label: str
    trigger_at: datetime
    callback: Callable
    repeat: bool = False
    repeat_interval_seconds: int = 0
    active: bool = True
    created_at: datetime = field(default_factory=datetime.now)


class TimerManager:
    """Manages all JARVIS timers and reminders."""

    def __init__(self, speak_callback: Optional[Callable[[str], None]] = None):
        self.timers: dict[str, TimerEntry] = {}
        self.speak = speak_callback or (lambda t: print(f"[TIMER] {t}"))
        self._running = True
        self._thread = threading.Thread(target=self._timer_loop, daemon=True)
        self._thread.start()

    def set_timer(
        self,
        seconds: int = 0,
        minutes: int = 0,
        hours: int = 0,
        label: str = "Timer",
        callback: Optional[Callable] = None
    ) -> dict:
        """Set a countdown timer."""
        total_seconds = seconds + (minutes * 60) + (hours * 3600)
        if total_seconds <= 0:
            return {"success": False, "error": "Timer duration must be positive."}

        timer_id = str(uuid.uuid4())[:8]
        trigger_at = datetime.now() + timedelta(seconds=total_seconds)

        def default_callback():
            duration_str = self._format_duration(total_seconds)
            msg = f"Timer complete! {label} — {duration_str} has elapsed."
            self.speak(msg)
            logger.info(f"Timer fired: {label}")

        entry = TimerEntry(
            id=timer_id,
            label=label,
            trigger_at=trigger_at,
            callback=callback or default_callback,
            active=True
        )
        self.timers[timer_id] = entry

        human_time = trigger_at.strftime("%H:%M:%S")
        logger.info(f"Timer set: {label} at {human_time}")
        return {
            "success": True,
            "id": timer_id,
            "label": label,
            "fires_at": human_time,
            "duration_seconds": total_seconds,
            "message": f"Timer '{label}' set for {self._format_duration(total_seconds)}."
        }

    def set_reminder(
        self,
        message: str,
        at: Optional[str] = None,
        in_minutes: int = 0,
        in_hours: int = 0,
    ) -> dict:
        """
        Set a reminder.
        at: "HH:MM" format for specific time
        in_minutes/in_hours: relative time
        """
        if at:
            try:
                today = datetime.now().date()
                trigger_time = datetime.strptime(f"{today} {at}", "%Y-%m-%d %H:%M")
                if trigger_time < datetime.now():
                    # Schedule for tomorrow
                    trigger_time += timedelta(days=1)
            except ValueError:
                return {"success": False, "error": f"Invalid time format: {at}. Use HH:MM"}
        elif in_minutes or in_hours:
            total_mins = in_minutes + (in_hours * 60)
            trigger_time = datetime.now() + timedelta(minutes=total_mins)
        else:
            return {"success": False, "error": "Specify either 'at' time or 'in_minutes'/'in_hours'"}

        timer_id = str(uuid.uuid4())[:8]

        def reminder_callback():
            msg = f"Reminder: {message}"
            self.speak(msg)
            try:
                from jarvis.messaging import MessagingHub
                MessagingHub().send_system_notification("JARVIS Reminder", message)
            except:
                pass

        entry = TimerEntry(
            id=timer_id,
            label=f"Reminder: {message[:30]}",
            trigger_at=trigger_time,
            callback=reminder_callback,
            active=True
        )
        self.timers[timer_id] = entry

        return {
            "success": True,
            "id": timer_id,
            "message": message,
            "fires_at": trigger_time.strftime("%H:%M on %B %d"),
        }

    def cancel_timer(self, timer_id: str) -> dict:
        """Cancel a timer by ID."""
        if timer_id in self.timers:
            self.timers[timer_id].active = False
            del self.timers[timer_id]
            return {"success": True, "cancelled": timer_id}
        return {"success": False, "error": f"Timer '{timer_id}' not found."}

    def list_timers(self) -> dict:
        """List all active timers."""
        active = []
        now = datetime.now()
        for t in self.timers.values():
            remaining = (t.trigger_at - now).total_seconds()
            if remaining > 0:
                active.append({
                    "id": t.id,
                    "label": t.label,
                    "fires_at": t.trigger_at.strftime("%H:%M:%S"),
                    "remaining_seconds": int(remaining),
                    "remaining": self._format_duration(int(remaining)),
                })
        return {"success": True, "timers": active, "count": len(active)}

    def _timer_loop(self):
        """Background loop that checks and fires timers."""
        while self._running:
            now = datetime.now()
            fired = []

            for timer_id, entry in list(self.timers.items()):
                if not entry.active:
                    fired.append(timer_id)
                    continue
                if now >= entry.trigger_at:
                    try:
                        entry.callback()
                    except Exception as e:
                        logger.error(f"Timer callback error: {e}")

                    if entry.repeat and entry.repeat_interval_seconds > 0:
                        entry.trigger_at = now + timedelta(seconds=entry.repeat_interval_seconds)
                    else:
                        fired.append(timer_id)

            for timer_id in fired:
                self.timers.pop(timer_id, None)

            time.sleep(1)

    def stop(self):
        self._running = False

    def _format_duration(self, seconds: int) -> str:
        """Format seconds into human-readable duration."""
        if seconds < 60:
            return f"{seconds} second{'s' if seconds != 1 else ''}"
        elif seconds < 3600:
            m, s = divmod(seconds, 60)
            return f"{m} minute{'s' if m != 1 else ''}" + (f" {s}s" if s else "")
        else:
            h, rem = divmod(seconds, 3600)
            m, s = divmod(rem, 60)
            return f"{h}h {m}m" + (f" {s}s" if s else "")
