"""
JARVIS Messaging Module — Send emails, notifications, and messages.
"""

import os
import smtplib
import logging
import subprocess
import platform
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional

logger = logging.getLogger("JARVIS.Messaging")


class MessagingHub:
    """Handles all messaging capabilities."""

    def __init__(self):
        self.email = os.getenv("EMAIL_ADDRESS", "")
        self.password = os.getenv("EMAIL_PASSWORD", "")
        self.smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.os_type = platform.system().lower()

    def send_email(
        self,
        to: str,
        subject: str,
        body: str,
        cc: Optional[str] = None
    ) -> dict:
        """Send an email via SMTP."""
        if not self.email or not self.password:
            return {
                "success": False,
                "error": "Email credentials not configured. Add EMAIL_ADDRESS and EMAIL_PASSWORD to .env"
            }

        try:
            msg = MIMEMultipart()
            msg["From"] = self.email
            msg["To"] = to
            msg["Subject"] = subject
            if cc:
                msg["Cc"] = cc

            msg.attach(MIMEText(body, "plain"))

            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.ehlo()
                server.starttls()
                server.login(self.email, self.password)
                recipients = [to] + ([cc] if cc else [])
                server.sendmail(self.email, recipients, msg.as_string())

            logger.info(f"Email sent to {to}: {subject}")
            return {"success": True, "to": to, "subject": subject}

        except smtplib.SMTPAuthenticationError:
            return {
                "success": False,
                "error": "Authentication failed. Check email/password in .env (use App Password for Gmail)."
            }
        except smtplib.SMTPException as e:
            return {"success": False, "error": f"SMTP error: {str(e)}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def send_system_notification(self, title: str, message: str, urgency: str = "normal") -> dict:
        """Send a native desktop notification."""
        try:
            if self.os_type == "windows":
                try:
                    from win10toast import ToastNotifier
                    toaster = ToastNotifier()
                    toaster.show_toast(title, message, duration=5, threaded=True)
                    return {"success": True, "method": "win10toast"}
                except ImportError:
                    # Fallback: PowerShell notification
                    ps_cmd = f"""
                    [Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime] | Out-Null
                    Add-Type -AssemblyName System.Windows.Forms
                    $n = New-Object System.Windows.Forms.NotifyIcon
                    $n.Icon = [System.Drawing.SystemIcons]::Information
                    $n.Visible = $true
                    $n.ShowBalloonTip(3000, '{title}', '{message}', [System.Windows.Forms.ToolTipIcon]::Info)
                    """
                    subprocess.Popen(["powershell", "-Command", ps_cmd],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return {"success": True, "method": "powershell"}

            elif self.os_type == "darwin":
                script = f'display notification "{message}" with title "{title}"'
                subprocess.Popen(["osascript", "-e", script])
                return {"success": True, "method": "osascript"}

            else:  # Linux
                subprocess.Popen(
                    ["notify-send", "-u", urgency, title, message],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
                return {"success": True, "method": "notify-send"}

        except Exception as e:
            return {"success": False, "error": str(e)}

    def open_whatsapp(self, phone: str = "", message: str = "") -> dict:
        """Open WhatsApp Web with an optional pre-filled message."""
        try:
            import webbrowser
            if phone and message:
                import urllib.parse
                encoded = urllib.parse.quote(message)
                url = f"https://wa.me/{phone}?text={encoded}"
            elif phone:
                url = f"https://wa.me/{phone}"
            else:
                url = "https://web.whatsapp.com"

            webbrowser.open(url)
            return {"success": True, "url": url}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def open_gmail_compose(self, to: str = "", subject: str = "", body: str = "") -> dict:
        """Open Gmail compose window in browser."""
        try:
            import webbrowser
            import urllib.parse
            params = {}
            if to: params["to"] = to
            if subject: params["su"] = subject
            if body: params["body"] = body
            query = urllib.parse.urlencode(params)
            url = f"https://mail.google.com/mail/?view=cm&fs=1&{query}" if params else "https://mail.google.com"
            webbrowser.open(url)
            return {"success": True, "url": url}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def copy_to_clipboard(self, text: str) -> dict:
        """Copy text to clipboard."""
        try:
            import pyperclip
            pyperclip.copy(text)
            return {"success": True, "copied": text[:50] + "..." if len(text) > 50 else text}
        except ImportError:
            # Fallback
            try:
                if self.os_type == "windows":
                    subprocess.run(["clip"], input=text.encode(), check=True)
                elif self.os_type == "darwin":
                    subprocess.run(["pbcopy"], input=text.encode(), check=True)
                else:
                    subprocess.run(["xclip", "-selection", "clipboard"], input=text.encode())
                return {"success": True}
            except Exception as e:
                return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_clipboard(self) -> dict:
        """Get text from clipboard."""
        try:
            import pyperclip
            text = pyperclip.paste()
            return {"success": True, "content": text}
        except Exception as e:
            return {"success": False, "error": str(e)}
