"""
JARVIS App Controller — Open and close applications by name.
Cross-platform: Windows, macOS, Linux.
"""

import os
import sys
import subprocess
import logging
import platform
from typing import Optional
import psutil

logger = logging.getLogger("JARVIS.Apps")

# Common app name aliases → executable mappings
APP_ALIASES = {
    # Browsers
    "chrome":        {"win": "chrome.exe",   "mac": "Google Chrome", "linux": "google-chrome"},
    "firefox":       {"win": "firefox.exe",  "mac": "Firefox",       "linux": "firefox"},
    "edge":          {"win": "msedge.exe",   "mac": "Microsoft Edge","linux": "microsoft-edge"},
    "brave":         {"win": "brave.exe",    "mac": "Brave Browser", "linux": "brave-browser"},
    "opera":         {"win": "opera.exe",    "mac": "Opera",         "linux": "opera"},
    # Code editors
    "vscode":        {"win": "Code.exe",     "mac": "Visual Studio Code", "linux": "code"},
    "code":          {"win": "Code.exe",     "mac": "Visual Studio Code", "linux": "code"},
    "vs code":       {"win": "Code.exe",     "mac": "Visual Studio Code", "linux": "code"},
    "visual studio": {"win": "devenv.exe",   "mac": "Visual Studio", "linux": ""},
    "sublime":       {"win": "sublime_text.exe", "mac": "Sublime Text", "linux": "subl"},
    "notepad++":     {"win": "notepad++.exe","mac": "",              "linux": ""},
    "notepad":       {"win": "notepad.exe",  "mac": "",              "linux": "gedit"},
    # Communication
    "discord":       {"win": "Discord.exe",  "mac": "Discord",       "linux": "discord"},
    "slack":         {"win": "slack.exe",    "mac": "Slack",         "linux": "slack"},
    "zoom":          {"win": "Zoom.exe",     "mac": "zoom.us",       "linux": "zoom"},
    "teams":         {"win": "Teams.exe",    "mac": "Microsoft Teams","linux": "teams"},
    "skype":         {"win": "Skype.exe",    "mac": "Skype",         "linux": "skype"},
    # Media
    "spotify":       {"win": "Spotify.exe",  "mac": "Spotify",       "linux": "spotify"},
    "vlc":           {"win": "vlc.exe",      "mac": "VLC",           "linux": "vlc"},
    "itunes":        {"win": "iTunes.exe",   "mac": "iTunes",        "linux": ""},
    # Office
    "word":          {"win": "WINWORD.EXE",  "mac": "Microsoft Word","linux": "soffice"},
    "excel":         {"win": "EXCEL.EXE",    "mac": "Microsoft Excel","linux": "soffice"},
    "powerpoint":    {"win": "POWERPNT.EXE", "mac": "Microsoft PowerPoint", "linux": "soffice"},
    # System
    "explorer":      {"win": "explorer.exe", "mac": "Finder",        "linux": "nautilus"},
    "terminal":      {"win": "cmd.exe",      "mac": "Terminal",      "linux": "gnome-terminal"},
    "cmd":           {"win": "cmd.exe",      "mac": "Terminal",      "linux": "bash"},
    "powershell":    {"win": "powershell.exe","mac": "",              "linux": ""},
    "task manager":  {"win": "taskmgr.exe",  "mac": "",              "linux": "gnome-system-monitor"},
    "calculator":    {"win": "calc.exe",     "mac": "Calculator",    "linux": "gnome-calculator"},
    "paint":         {"win": "mspaint.exe",  "mac": "",              "linux": "gimp"},
    "snipping tool": {"win": "SnippingTool.exe","mac": "",           "linux": "gnome-screenshot"},
    # Others
    "steam":         {"win": "steam.exe",    "mac": "Steam",         "linux": "steam"},
    "obs":           {"win": "obs64.exe",    "mac": "OBS",           "linux": "obs"},
    "photoshop":     {"win": "Photoshop.exe","mac": "Adobe Photoshop","linux": ""},
    "premiere":      {"win": "Adobe Premiere Pro.exe","mac": "Adobe Premiere Pro","linux": ""},
}


class AppController:
    """Controls launching and closing applications."""

    def __init__(self):
        self.os_type = platform.system().lower()  # windows/darwin/linux

    def open_app(self, app_name: str) -> dict:
        """Open an application by name."""
        app_lower = app_name.lower().strip()

        # Look up alias
        executable = self._resolve_executable(app_lower)
        if not executable:
            executable = app_name  # Try as-is

        try:
            if self.os_type == "windows":
                result = self._open_windows(executable, app_lower)
            elif self.os_type == "darwin":
                result = self._open_mac(executable, app_lower)
            else:
                result = self._open_linux(executable, app_lower)

            return result

        except Exception as e:
            logger.error(f"Error opening {app_name}: {e}")
            return {"success": False, "app": app_name, "error": str(e)}

    def close_app(self, app_name: str, force: bool = False) -> dict:
        """Close an application by name."""
        app_lower = app_name.lower().strip()
        executable = self._resolve_executable(app_lower) or app_name
        exe_lower = executable.lower().replace(".exe", "")

        killed = []
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                proc_name = (proc.info["name"] or "").lower()
                cmdline = " ".join(proc.info.get("cmdline") or []).lower()

                if (exe_lower in proc_name or
                        app_lower in proc_name or
                        app_lower in cmdline):
                    if force:
                        proc.kill()
                    else:
                        proc.terminate()
                    killed.append(proc.info["name"])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        if killed:
            return {"success": True, "app": app_name, "closed": list(set(killed))}
        else:
            return {
                "success": False,
                "app": app_name,
                "error": f"No running process found for '{app_name}'."
            }

    def list_running_apps(self) -> dict:
        """List all currently running applications."""
        apps = set()
        for proc in psutil.process_iter(["name", "status"]):
            try:
                if proc.info["status"] == psutil.STATUS_RUNNING:
                    apps.add(proc.info["name"])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return {"success": True, "running": sorted(apps)}

    def _resolve_executable(self, name: str) -> Optional[str]:
        """Resolve app alias to executable name."""
        os_key = {"windows": "win", "darwin": "mac"}.get(self.os_type, "linux")
        # Exact match
        if name in APP_ALIASES:
            return APP_ALIASES[name].get(os_key, "")
        # Partial match
        for alias, execs in APP_ALIASES.items():
            if alias in name or name in alias:
                return execs.get(os_key, "")
        return None

    def _open_windows(self, executable: str, original: str) -> dict:
        """Open app on Windows."""
        try:
            os.startfile(executable)
            return {"success": True, "app": original, "method": "startfile"}
        except (FileNotFoundError, OSError):
            pass

        # Try subprocess
        try:
            subprocess.Popen(
                executable,
                shell=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return {"success": True, "app": original, "method": "subprocess"}
        except Exception as e:
            return {"success": False, "app": original, "error": str(e)}

    def _open_mac(self, app: str, original: str) -> dict:
        """Open app on macOS."""
        # Try 'open -a AppName'
        try:
            result = subprocess.Popen(
                ["open", "-a", app],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return {"success": True, "app": original, "method": "open -a"}
        except Exception:
            pass

        # Try direct command
        try:
            subprocess.Popen(app, shell=True)
            return {"success": True, "app": original, "method": "direct"}
        except Exception as e:
            return {"success": False, "app": original, "error": str(e)}

    def _open_linux(self, executable: str, original: str) -> dict:
        """Open app on Linux."""
        try:
            subprocess.Popen(
                executable,
                shell=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return {"success": True, "app": original, "method": "subprocess"}
        except Exception as e:
            return {"success": False, "app": original, "error": str(e)}

    def get_app_info(self, app_name: str) -> dict:
        """Get info about a running application."""
        app_lower = app_name.lower()
        results = []
        for proc in psutil.process_iter(["pid", "name", "memory_percent", "cpu_percent", "status"]):
            try:
                if app_lower in (proc.info["name"] or "").lower():
                    results.append({
                        "pid": proc.info["pid"],
                        "name": proc.info["name"],
                        "memory_percent": round(proc.info["memory_percent"], 2),
                        "cpu_percent": proc.info["cpu_percent"],
                        "status": proc.info["status"],
                    })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        return {"success": True, "app": app_name, "instances": results}
