"""
JARVIS Icon Generator — Creates the neon JARVIS icon with "Made by iHuevy".
Generates icon.png in the assets folder.
"""

import os
from pathlib import Path


def create_jarvis_icon(size: int = 256, output_path: str = None) -> str:
    """Generate the JARVIS neon icon. Returns path to saved PNG."""
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageFilter
        import math

        output_path = output_path or str(Path(__file__).parent.parent / "assets" / "icon.png")
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        # Create base image (dark background)
        img = Image.new("RGBA", (size, size), (0, 0, 0, 255))
        draw = ImageDraw.Draw(img)

        cx, cy = size // 2, size // 2
        r = size // 2 - 8

        # ── Outer glow ring ──────────────────────────────────────────────────
        for glow_r in range(r, r - 12, -1):
            alpha = int(255 * (1 - (r - glow_r) / 12) * 0.3)
            draw.ellipse(
                [cx - glow_r, cy - glow_r, cx + glow_r, cy + glow_r],
                outline=(0, 212, 255, alpha)
            )

        # ── Solid circle background ──────────────────────────────────────────
        draw.ellipse(
            [cx - r + 12, cy - r + 12, cx + r - 12, cy + r - 12],
            fill=(5, 15, 30, 255)
        )

        # ── Outer ring ───────────────────────────────────────────────────────
        draw.ellipse(
            [cx - r + 4, cy - r + 4, cx + r - 4, cy + r - 4],
            outline=(0, 212, 255), width=3
        )
        draw.ellipse(
            [cx - r + 8, cy - r + 8, cx + r - 8, cy + r - 8],
            outline=(0, 150, 200), width=1
        )

        # ── Hexagon ───────────────────────────────────────────────────────────
        hex_r = int(r * 0.65)
        hex_points = []
        for i in range(6):
            angle = math.radians(60 * i - 30)
            hx = cx + int(hex_r * math.cos(angle))
            hy = cy + int(hex_r * math.sin(angle))
            hex_points.append((hx, hy))
        draw.polygon(hex_points, outline=(0, 212, 255), fill=(0, 30, 60, 200))

        # Inner hexagon
        hex_r2 = int(hex_r * 0.75)
        hex_points2 = []
        for i in range(6):
            angle = math.radians(60 * i - 30)
            hx = cx + int(hex_r2 * math.cos(angle))
            hy = cy + int(hex_r2 * math.sin(angle))
            hex_points2.append((hx, hy))
        draw.polygon(hex_points2, outline=(0, 180, 230), fill=(0, 20, 50, 255))

        # ── J letter (JARVIS) ─────────────────────────────────────────────────
        # Draw stylized "J" in neon cyan
        j_size = int(size * 0.28)
        j_x = cx - j_size // 2
        j_y = cy - j_size // 2 - int(size * 0.03)
        j_w = int(j_size * 0.6)
        j_h = j_size
        stroke = max(3, size // 48)

        # Vertical bar of J
        draw.rectangle(
            [j_x + j_w - stroke, j_y, j_x + j_w + stroke, j_y + int(j_h * 0.75)],
            fill=(0, 212, 255)
        )
        # Horizontal top of J
        draw.rectangle(
            [j_x, j_y, j_x + j_w + stroke, j_y + stroke * 2],
            fill=(0, 212, 255)
        )
        # Curve bottom of J
        curve_r = int(j_w * 0.55)
        curve_cx = j_x + j_w - stroke
        curve_cy = j_y + int(j_h * 0.75)
        draw.arc(
            [curve_cx - curve_r, curve_cy - curve_r // 2,
             curve_cx + curve_r // 2, curve_cy + curve_r // 2],
            start=0, end=200, fill=(0, 212, 255), width=stroke + 1
        )

        # ── Corner accent dots ─────────────────────────────────────────────────
        dot_r = max(3, size // 48)
        for angle_deg in [0, 60, 120, 180, 240, 300]:
            angle = math.radians(angle_deg - 30)
            dx = cx + int((r - 18) * math.cos(angle))
            dy = cy + int((r - 18) * math.sin(angle))
            draw.ellipse([dx - dot_r, dy - dot_r, dx + dot_r, dy + dot_r], fill=(0, 212, 255))

        # ── Scanline effect ────────────────────────────────────────────────────
        for y in range(0, size, 4):
            draw.line([(0, y), (size, y)], fill=(0, 0, 0, 30), width=1)

        # ── Apply glow blur ───────────────────────────────────────────────────
        img_blur = img.filter(ImageFilter.GaussianBlur(radius=2))
        img = Image.blend(img, img_blur, alpha=0.15)

        # Save PNG
        img.save(output_path, "PNG")
        print(f"[JARVIS] Icon saved: {output_path}")
        return output_path

    except ImportError:
        print("[JARVIS] Pillow not installed — using fallback icon.")
        return _create_fallback_icon(output_path or "assets/icon.png")
    except Exception as e:
        print(f"[JARVIS] Icon generation failed: {e}")
        return ""


def _create_fallback_icon(output_path: str) -> str:
    """Fallback: create a minimal icon using tkinter."""
    try:
        import tkinter as tk
        # Just return an empty path for now
        return ""
    except:
        return ""


def create_tray_icon_image(size: int = 64):
    """Create a PIL Image for the system tray (small version)."""
    try:
        from PIL import Image
        path = create_jarvis_icon(size, output_path=None)
        if path:
            return Image.open(path).resize((size, size))
    except:
        pass

    # Fallback: plain colored circle
    try:
        from PIL import Image, ImageDraw
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.ellipse([2, 2, size - 2, size - 2], fill=(0, 212, 255, 230))
        draw.text((size // 2 - 5, size // 2 - 8), "J", fill=(0, 0, 30), font=None)
        return img
    except:
        return None


if __name__ == "__main__":
    create_jarvis_icon(256)
